package com.example.ui.components

import androidx.compose.animation.animateColorAsState
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.aspectRatio
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.BookmarkBorder
import androidx.compose.material.icons.filled.ChatBubbleOutline
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Share
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisRose
import com.example.ui.theme.NexisViolet

@Composable
fun PostCard(
  post: Post,
  onAppreciateClick: () -> Unit,
  onCommentClick: () -> Unit,
  onShareClick: () -> Unit,
  onSaveClick: () -> Unit,
  onReportClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Card(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 6.dp)
      .testTag("post_card_${post.id}"),
    shape = RoundedCornerShape(20.dp),
    colors = CardDefaults.cardColors(
      containerColor = MaterialTheme.colorScheme.surface,
    ),
    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
    border = CardDefaults.outlinedCardBorder().copy(
      brush = Brush.verticalGradient(
        listOf(
          MaterialTheme.colorScheme.outline.copy(alpha = 0.25f),
          MaterialTheme.colorScheme.outline.copy(alpha = 0.08f),
        ),
      ),
    ),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .padding(16.dp),
    ) {
      // 1. Author Header & Badges
      Row(
        modifier = Modifier.fillMaxWidth(),
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // Avatar
        Box(
          modifier = Modifier
            .size(46.dp)
            .clip(CircleShape)
            .background(MaterialTheme.colorScheme.surfaceVariant)
            .border(
              width = if (post.isCreatorPost) 2.dp else 1.dp,
              brush = if (post.isCreatorPost) Brush.linearGradient(listOf(NexisViolet, NexisCyan)) else Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline, MaterialTheme.colorScheme.outline)),
              shape = CircleShape,
            ),
        ) {
          if (post.authorAvatar.isNotBlank()) {
            AsyncImage(
              model = post.authorAvatar,
              contentDescription = "${post.authorName} avatar",
              contentScale = ContentScale.Crop,
              modifier = Modifier.matchParentSize(),
            )
          } else {
            Box(
              modifier = Modifier.matchParentSize(),
              contentAlignment = Alignment.Center,
            ) {
              Text(
                text = post.authorName.take(1).uppercase(),
                style = MaterialTheme.typography.titleMedium,
                color = MaterialTheme.colorScheme.primary,
              )
            }
          }
        }

        Spacer(modifier = Modifier.width(12.dp))

        // Name, Handle, Time
        Column(modifier = Modifier.weight(1f)) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = post.authorName,
              style = MaterialTheme.typography.titleMedium.copy(
                fontWeight = FontWeight.SemiBold,
                fontSize = 15.sp,
              ),
              color = MaterialTheme.colorScheme.onSurface,
            )

            if (post.isCreatorPost) {
              Spacer(modifier = Modifier.width(6.dp))
              Surface(
                shape = RoundedCornerShape(6.dp),
                color = NexisViolet.copy(alpha = 0.15f),
                border = CardDefaults.outlinedCardBorder().copy(
                  brush = Brush.horizontalGradient(listOf(NexisViolet, NexisCyan)),
                ),
              ) {
                Row(
                  modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                  verticalAlignment = Alignment.CenterVertically,
                ) {
                  Icon(
                    imageVector = Icons.Default.AutoAwesome,
                    contentDescription = "Creator Space",
                    tint = NexisCyan,
                    modifier = Modifier.size(10.dp),
                  )
                  Spacer(modifier = Modifier.width(3.dp))
                  Text(
                    text = "CREATOR",
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                    color = NexisCyan,
                  )
                }
              }
            }
          }

          Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp),
          ) {
            Text(
              text = "@${post.authorHandle}",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant,
            )
            Text(
              text = "•",
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f),
            )
            Text(
              text = formatTimeAgo(post.timestamp),
              style = MaterialTheme.typography.bodySmall,
              color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            )
          }
        }

        // Community badge if attached
        if (!post.communityName.isNullOrBlank()) {
          Surface(
            shape = RoundedCornerShape(12.dp),
            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
          ) {
            Row(
              modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              verticalAlignment = Alignment.CenterVertically,
            ) {
              Icon(
                imageVector = Icons.Default.Groups,
                contentDescription = null,
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier.size(12.dp),
              )
              Spacer(modifier = Modifier.width(4.dp))
              Text(
                text = post.communityName,
                style = MaterialTheme.typography.labelSmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(12.dp))

      // 2. Post Content Text
      if (post.content.isNotBlank()) {
        Text(
          text = post.content,
          style = MaterialTheme.typography.bodyMedium.copy(
            lineHeight = 22.sp,
            fontSize = 14.5.sp,
          ),
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      // 3. Media: Single or Multi-Image
      if (post.imageUrls.isNotEmpty()) {
        Spacer(modifier = Modifier.height(12.dp))

        if (post.imageUrls.size == 1) {
          // Single Image
          Box(
            modifier = Modifier
              .fillMaxWidth()
              .aspectRatio(16f / 10f)
              .clip(RoundedCornerShape(14.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant),
          ) {
            AsyncImage(
              model = post.imageUrls.first(),
              contentDescription = "Post image",
              contentScale = ContentScale.Crop,
              modifier = Modifier.matchParentSize(),
            )
          }
        } else {
          // Multi-Image Gallery
          Column {
            Row(
              modifier = Modifier
                .fillMaxWidth()
                .horizontalScroll(rememberScrollState()),
              horizontalArrangement = Arrangement.spacedBy(8.dp),
            ) {
              post.imageUrls.forEachIndexed { index, url ->
                Box(
                  modifier = Modifier
                    .size(width = 240.dp, height = 180.dp)
                    .clip(RoundedCornerShape(14.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant),
                ) {
                  AsyncImage(
                    model = url,
                    contentDescription = "Post image ${index + 1}",
                    contentScale = ContentScale.Crop,
                    modifier = Modifier.matchParentSize(),
                  )

                  // Image index pill
                  Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color.Black.copy(alpha = 0.65f),
                    modifier = Modifier
                      .align(Alignment.TopEnd)
                      .padding(8.dp),
                  ) {
                    Text(
                      text = "${index + 1}/${post.imageUrls.size}",
                      color = Color.White,
                      fontSize = 10.sp,
                      fontWeight = FontWeight.Medium,
                      modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    )
                  }
                }
              }
            }
          }
        }
      }

      Spacer(modifier = Modifier.height(14.dp))

      // 4. Five-Action Interaction Bar (Appreciate, Comment, Share, Save, Report)
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .testTag("interaction_bar_${post.id}"),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        // 1. Appreciate
        val appreciateColor by animateColorAsState(
          targetValue = if (post.isAppreciated) NexisRose else MaterialTheme.colorScheme.onSurfaceVariant,
          label = "appreciate_color",
        )
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onAppreciateClick)
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .testTag("action_appreciate_${post.id}"),
        ) {
          Icon(
            imageVector = if (post.isAppreciated) Icons.Filled.Favorite else Icons.Filled.FavoriteBorder,
            contentDescription = "Appreciate",
            tint = appreciateColor,
            modifier = Modifier.size(20.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = formatCount(post.appreciatesCount),
            style = MaterialTheme.typography.labelMedium,
            color = appreciateColor,
          )
        }

        // 2. Comment
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onCommentClick)
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .testTag("action_comment_${post.id}"),
        ) {
          Icon(
            imageVector = Icons.Filled.ChatBubbleOutline,
            contentDescription = "Comment",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(19.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = formatCount(post.commentsCount),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        // 3. Share
        Row(
          verticalAlignment = Alignment.CenterVertically,
          modifier = Modifier
            .clip(RoundedCornerShape(8.dp))
            .clickable(onClick = onShareClick)
            .padding(horizontal = 4.dp, vertical = 6.dp)
            .testTag("action_share_${post.id}"),
        ) {
          Icon(
            imageVector = Icons.Filled.Share,
            contentDescription = "Share",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
            modifier = Modifier.size(19.dp),
          )
          Spacer(modifier = Modifier.width(4.dp))
          Text(
            text = formatCount(post.sharesCount),
            style = MaterialTheme.typography.labelMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        // 4. Save
        val saveColor by animateColorAsState(
          targetValue = if (post.isSaved) NexisCyan else MaterialTheme.colorScheme.onSurfaceVariant,
          label = "save_color",
        )
        IconButton(
          onClick = onSaveClick,
          modifier = Modifier
            .size(36.dp)
            .testTag("action_save_${post.id}"),
        ) {
          Icon(
            imageVector = if (post.isSaved) Icons.Filled.Bookmark else Icons.Filled.BookmarkBorder,
            contentDescription = if (post.isSaved) "Saved" else "Save",
            tint = saveColor,
            modifier = Modifier.size(20.dp),
          )
        }

        // 5. Report
        IconButton(
          onClick = onReportClick,
          modifier = Modifier
            .size(36.dp)
            .testTag("action_report_${post.id}"),
        ) {
          Icon(
            imageVector = Icons.Filled.Flag,
            contentDescription = "Report",
            tint = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
            modifier = Modifier.size(19.dp),
          )
        }
      }
    }
  }
}

private fun formatCount(count: Int): String {
  return when {
    count >= 1_000_000 -> String.format("%.1fM", count / 1_000_000.0)
    count >= 1_000 -> String.format("%.1fK", count / 1_000.0)
    else -> count.toString()
  }
}

private fun formatTimeAgo(timestamp: Long): String {
  val diff = System.currentTimeMillis() - timestamp
  val minutes = diff / (1000 * 60)
  val hours = minutes / 60
  val days = hours / 24

  return when {
    minutes < 1 -> "just now"
    minutes < 60 -> "${minutes}m ago"
    hours < 24 -> "${hours}h ago"
    days < 7 -> "${days}d ago"
    else -> "${days / 7}w ago"
  }
}
