package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Public
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.FilterChip
import androidx.compose.material3.FilterChipDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.model.Community
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet

@Composable
fun CreateTextPostDialog(
  communities: List<Community>,
  onDismiss: () -> Unit,
  onPublish: (content: String, isCreatorSpace: Boolean, communityId: String?, communityName: String?) -> Unit,
) {
  var content by remember { mutableStateOf("") }
  var isCreatorSpace by remember { mutableStateOf(false) }
  var selectedCommunity by remember { mutableStateOf<Community?>(null) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.EditNote,
        contentDescription = null,
        tint = NexisViolet,
        modifier = Modifier.size(32.dp),
      )
    },
    title = {
      Text(
        text = "Publish Text Post",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          label = { Text("What's unfolding in your world?") },
          placeholder = { Text("Share an insight, question, or thought...") },
          modifier = Modifier
            .fillMaxWidth()
            .height(140.dp)
            .testTag("text_post_input"),
          maxLines = 6,
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Creator Space Toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = Icons.Default.AutoAwesome,
              contentDescription = null,
              tint = NexisCyan,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = "Post to Creator Space",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
              )
              Text(
                text = "Highlight with official creator badge",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Switch(
            checked = isCreatorSpace,
            onCheckedChange = { isCreatorSpace = it },
            modifier = Modifier.testTag("toggle_creator_post"),
          )
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Community selector
        Text(
          text = "Tag Community (Optional)",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(6.dp))
        LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
          items(communities) { community ->
            val isSelected = selectedCommunity?.id == community.id
            FilterChip(
              selected = isSelected,
              onClick = {
                selectedCommunity = if (isSelected) null else community
              },
              label = { Text(community.name, fontSize = 12.sp) },
              colors = FilterChipDefaults.filterChipColors(
                selectedContainerColor = MaterialTheme.colorScheme.primaryContainer,
                selectedLabelColor = MaterialTheme.colorScheme.onPrimaryContainer,
              ),
            )
          }
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onPublish(content, isCreatorSpace, selectedCommunity?.id, selectedCommunity?.name)
        },
        enabled = content.isNotBlank(),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("publish_text_post_button"),
      ) {
        Text("Publish")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(12.dp)) {
        Text("Cancel")
      }
    },
    modifier = Modifier.testTag("create_text_post_dialog"),
  )
}

@Composable
fun CreateImagePostDialog(
  communities: List<Community>,
  onDismiss: () -> Unit,
  onPublish: (content: String, imageUrls: List<String>, isCreatorSpace: Boolean, communityId: String?, communityName: String?) -> Unit,
) {
  var content by remember { mutableStateOf("") }
  var isCreatorSpace by remember { mutableStateOf(false) }
  var selectedCommunity by remember { mutableStateOf<Community?>(null) }
  var customImageUrl by remember { mutableStateOf("") }

  val presetImages = listOf(
    "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
    "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
    "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&q=80",
    "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
    "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&q=80",
  )

  var selectedImages by remember {
    mutableStateOf(listOf(presetImages.first()))
  }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.AddPhotoAlternate,
        contentDescription = null,
        tint = NexisCyan,
        modifier = Modifier.size(32.dp),
      )
    },
    title = {
      Text(
        text = "Publish Visual Post",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        OutlinedTextField(
          value = content,
          onValueChange = { content = it },
          label = { Text("Caption or story") },
          placeholder = { Text("Describe the visual piece...") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("image_post_caption_input"),
          maxLines = 3,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Text(
          text = "Select Media (${selectedImages.size} selected)",
          style = MaterialTheme.typography.labelMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
        Spacer(modifier = Modifier.height(8.dp))

        // Preset Gallery
        LazyRow(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          items(presetImages) { url ->
            val isPicked = selectedImages.contains(url)
            Box(
              modifier = Modifier
                .size(70.dp)
                .clip(RoundedCornerShape(12.dp))
                .border(
                  width = if (isPicked) 3.dp else 1.dp,
                  color = if (isPicked) NexisCyan else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                  shape = RoundedCornerShape(12.dp),
                )
                .clickable {
                  selectedImages = if (isPicked) {
                    if (selectedImages.size > 1) selectedImages - url else selectedImages
                  } else {
                    selectedImages + url
                  }
                },
            ) {
              AsyncImage(
                model = url,
                contentDescription = "Visual preset",
                contentScale = ContentScale.Crop,
                modifier = Modifier.matchParentSize(),
              )
              if (isPicked) {
                Box(
                  modifier = Modifier
                    .matchParentSize()
                    .background(NexisCyan.copy(alpha = 0.3f)),
                  contentAlignment = Alignment.Center,
                ) {
                  Icon(
                    imageVector = Icons.Default.Check,
                    contentDescription = "Selected",
                    tint = Color.White,
                  )
                }
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
          value = customImageUrl,
          onValueChange = { customImageUrl = it },
          label = { Text("Or paste image URL") },
          placeholder = { Text("https://...") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
          trailingIcon = {
            if (customImageUrl.isNotBlank()) {
              IconButton(onClick = {
                selectedImages = selectedImages + customImageUrl.trim()
                customImageUrl = ""
              }) {
                Icon(imageVector = Icons.Default.Check, contentDescription = "Add image", tint = NexisCyan)
              }
            }
          },
        )

        Spacer(modifier = Modifier.height(14.dp))

        // Creator Space Toggle
        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Text(
            text = "Publish to Creator Space",
            style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
          )
          Switch(checked = isCreatorSpace, onCheckedChange = { isCreatorSpace = it })
        }
      }
    },
    confirmButton = {
      Button(
        onClick = {
          onPublish(content, selectedImages, isCreatorSpace, selectedCommunity?.id, selectedCommunity?.name)
        },
        enabled = selectedImages.isNotEmpty(),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("publish_image_post_button"),
      ) {
        Text("Publish Post")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(12.dp)) {
        Text("Cancel")
      }
    },
    modifier = Modifier.testTag("create_image_post_dialog"),
  )
}

@Composable
fun CreateCommunityDialog(
  onDismiss: () -> Unit,
  onCreate: (name: String, description: String, category: String, isPrivate: Boolean) -> Unit,
) {
  var name by remember { mutableStateOf("") }
  var description by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Tech & Design") }
  var isPrivate by remember { mutableStateOf(false) }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Groups,
        contentDescription = null,
        tint = Color(0xFF10B981),
        modifier = Modifier.size(32.dp),
      )
    },
    title = {
      Text(
        text = "Create Community",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Community Name") },
          placeholder = { Text("e.g., Cyberpunk UI Designers") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("community_name_input"),
          singleLine = true,
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = description,
          onValueChange = { description = it },
          label = { Text("Description") },
          placeholder = { Text("What is this collective about?") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("community_desc_input"),
          maxLines = 3,
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Category") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
        )

        Spacer(modifier = Modifier.height(14.dp))

        Row(
          modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(12.dp))
            .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            .padding(horizontal = 12.dp, vertical = 8.dp),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          Row(verticalAlignment = Alignment.CenterVertically) {
            Icon(
              imageVector = if (isPrivate) Icons.Default.Lock else Icons.Default.Public,
              contentDescription = null,
              tint = MaterialTheme.colorScheme.onSurfaceVariant,
              modifier = Modifier.size(20.dp),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = if (isPrivate) "Private Collective" else "Public Collective",
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
              )
              Text(
                text = if (isPrivate) "Membership requires creator approval" else "Anyone on NEXIS can join and participate",
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
          Switch(checked = isPrivate, onCheckedChange = { isPrivate = it })
        }
      }
    },
    confirmButton = {
      Button(
        onClick = { onCreate(name, description, category, isPrivate) },
        enabled = name.isNotBlank(),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("confirm_create_community_button"),
      ) {
        Text("Create")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(12.dp)) {
        Text("Cancel")
      }
    },
    modifier = Modifier.testTag("create_community_dialog"),
  )
}

@Composable
fun CreateSpaceDialog(
  onDismiss: () -> Unit,
  onCreate: (name: String, tagLine: String, category: String) -> Unit,
) {
  var name by remember { mutableStateOf("") }
  var tagLine by remember { mutableStateOf("") }
  var category by remember { mutableStateOf("Digital Arts & Technology") }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.AutoAwesome,
        contentDescription = null,
        tint = Color(0xFFF59E0B),
        modifier = Modifier.size(32.dp),
      )
    },
    title = {
      Text(
        text = "Launch Creator Space",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        Text(
          text = "Creator Spaces grant you verified branding, broadcast channels, audience analytics, and portfolio showcases.",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(14.dp))

        OutlinedTextField(
          value = name,
          onValueChange = { name = it },
          label = { Text("Creator Space Name") },
          placeholder = { Text("e.g. Apex Visuals Studio") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("space_name_input"),
          singleLine = true,
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = tagLine,
          onValueChange = { tagLine = it },
          label = { Text("Tagline / Mission") },
          placeholder = { Text("High-fidelity creative explorations") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("space_tagline_input"),
          maxLines = 2,
        )

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = category,
          onValueChange = { category = it },
          label = { Text("Creator Niche") },
          modifier = Modifier.fillMaxWidth(),
          singleLine = true,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onCreate(name, tagLine, category) },
        enabled = name.isNotBlank(),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("confirm_create_space_button"),
      ) {
        Text("Launch Space")
      }
    },
    dismissButton = {
      OutlinedButton(onClick = onDismiss, shape = RoundedCornerShape(12.dp)) {
        Text("Cancel")
      }
    },
    modifier = Modifier.testTag("create_space_dialog"),
  )
}

@Composable
fun DisabledVideoUploadNoticeDialog(
  onDismiss: () -> Unit,
) {
  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Box(
        modifier = Modifier
          .size(54.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = Icons.Default.VideocamOff,
          contentDescription = null,
          tint = MaterialTheme.colorScheme.primary,
          modifier = Modifier.size(28.dp),
        )
      }
    },
    title = {
      Text(
        text = "Video Uploading",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
      )
    },
    text = {
      Column(modifier = Modifier.fillMaxWidth()) {
        Text(
          text = "Video uploading will be available in a future update.",
          style = MaterialTheme.typography.bodyLarge.copy(
            fontWeight = FontWeight.SemiBold,
            color = MaterialTheme.colorScheme.onSurface,
          ),
        )
        Spacer(modifier = Modifier.height(8.dp))
        Text(
          text = "Our high-throughput adaptive video transcoding and edge content delivery pipeline is currently undergoing early access validation with verified partner studios. Thank you for your patience!",
          style = MaterialTheme.typography.bodyMedium,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = onDismiss,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("dismiss_video_notice_button"),
      ) {
        Text("Understood")
      }
    },
    modifier = Modifier.testTag("video_upload_notice_dialog"),
  )
}
