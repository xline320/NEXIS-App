package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// NEXIS Modern Cyber/Future Color Palette
val NexisViolet = Color(0xFF7C3AED)
val NexisVioletLight = Color(0xFFA78BFA)
val NexisVioletDark = Color(0xFF5B21B6)

val NexisCyan = Color(0xFF06B6D4)
val NexisCyanLight = Color(0xFF67E8F9)
val NexisCyanDark = Color(0xFF0E7490)

val NexisRose = Color(0xFFF43F5E)
val NexisRoseLight = Color(0xFFFDA4AF)

val NexisDarkBg = Color(0xFF090D16)
val NexisDarkSurface = Color(0xFF111827)
val NexisDarkSurfaceVariant = Color(0xFF1F2937)
val NexisDarkBorder = Color(0xFF374151)

val NexisLightBg = Color(0xFFF8FAFC)
val NexisLightSurface = Color(0xFFFFFFFF)
val NexisLightSurfaceVariant = Color(0xFFF1F5F9)
val NexisLightBorder = Color(0xFFE2E8F0)

// Legacy aliases for backward compatibility with existing tests
val Purple80 = NexisVioletLight
val PurpleGrey80 = NexisCyanLight
val Pink80 = NexisRoseLight
val Purple40 = NexisViolet
val PurpleGrey40 = NexisCyan
val Pink40 = NexisRose
