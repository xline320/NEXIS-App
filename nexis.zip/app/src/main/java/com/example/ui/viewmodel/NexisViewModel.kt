package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.NexisDatabase
import com.example.data.model.Comment
import com.example.data.model.Community
import com.example.data.model.CreatorSpace
import com.example.data.model.Post
import com.example.data.model.Profile
import com.example.data.model.ReportReason
import com.example.data.model.VideoItem
import com.example.data.remote.FirebaseClient
import com.example.data.repository.AuthRepository
import com.example.data.repository.CommunityRepository
import com.example.data.repository.PostRepository
import com.example.data.repository.ProfileRepository
import kotlinx.coroutines.flow.MutableSharedFlow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharedFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asSharedFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import java.util.UUID

enum class BottomTab {
  HOME,
  VIDEO,
}

enum class ActiveScreen {
  FEED,
  PROFILE,
  COMMUNITIES,
  CREATOR_SPACES,
}

enum class ProfileIdentity {
  SOCIAL,
  CREATOR,
}

sealed class CreateDialogType {
  data object None : CreateDialogType()
  data object TextPost : CreateDialogType()
  data object ImagePost : CreateDialogType()
  data object CreateCommunity : CreateDialogType()
  data object CreateSpace : CreateDialogType()
}

class NexisViewModel(application: Application) : AndroidViewModel(application) {
  private val database = NexisDatabase.getDatabase(application)

  val authRepository: AuthRepository
  val postRepository: PostRepository
  val profileRepository: ProfileRepository
  val communityRepository: CommunityRepository

  init {
    FirebaseClient.init(application)
    authRepository = AuthRepository(application, database)
    postRepository = PostRepository(database)
    profileRepository = ProfileRepository(database)
    communityRepository = CommunityRepository(database)
  }

  // Navigation State
  private val _currentTab = MutableStateFlow(BottomTab.HOME)
  val currentTab: StateFlow<BottomTab> = _currentTab.asStateFlow()

  private val _activeScreen = MutableStateFlow(ActiveScreen.FEED)
  val activeScreen: StateFlow<ActiveScreen> = _activeScreen.asStateFlow()

  // Profile Identity Switcher (Social Profile vs Creator Space)
  private val _profileIdentity = MutableStateFlow(ProfileIdentity.SOCIAL)
  val profileIdentity: StateFlow<ProfileIdentity> = _profileIdentity.asStateFlow()

  // Overlays
  private val _isUniversalCreateOpen = MutableStateFlow(false)
  val isUniversalCreateOpen: StateFlow<Boolean> = _isUniversalCreateOpen.asStateFlow()

  private val _activeCreateDialog = MutableStateFlow<CreateDialogType>(CreateDialogType.None)
  val activeCreateDialog: StateFlow<CreateDialogType> = _activeCreateDialog.asStateFlow()

  private val _activeCommentPost = MutableStateFlow<Post?>(null)
  val activeCommentPost: StateFlow<Post?> = _activeCommentPost.asStateFlow()

  private val _activeReportPost = MutableStateFlow<Post?>(null)
  val activeReportPost: StateFlow<Post?> = _activeReportPost.asStateFlow()

  private val _showVideoUploadNotice = MutableStateFlow(false)
  val showVideoUploadNotice: StateFlow<Boolean> = _showVideoUploadNotice.asStateFlow()

  // Snackbar notifications
  private val _snackbarMessages = MutableSharedFlow<String>()
  val snackbarMessages: SharedFlow<String> = _snackbarMessages.asSharedFlow()

  // Data streams
  val currentUser: StateFlow<Profile?> = authRepository.currentUser
  val feedPosts: StateFlow<List<Post>> = postRepository.getFeedPosts()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  val communities: StateFlow<List<Community>> = communityRepository.getCommunities()
    .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

  // Video universe discovery items
  private val _videos = MutableStateFlow(
    listOf(
      VideoItem(
        id = "vid_1",
        title = "Generative Spatial Interfaces: Next Decade of UX",
        creatorName = "Nexis Studio Hub",
        creatorHandle = "nexis_studio",
        creatorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
        duration = "2:45",
        views = "342K",
        appreciatesCount = 18400,
        commentsCount = 620,
        tags = listOf("Design", "AI", "Compose"),
        isShort = false,
      ),
      VideoItem(
        id = "vid_2",
        title = "Tokyo Midnight Cyberpunk Soundscapes [Ambient Synths]",
        creatorName = "Kai Chen",
        creatorHandle = "kaichen_lens",
        creatorAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&q=80",
        duration = "0:58",
        views = "890K",
        appreciatesCount = 56200,
        commentsCount = 1940,
        tags = listOf("Shorts", "Music", "Tokyo"),
        isShort = true,
      ),
      VideoItem(
        id = "vid_3",
        title = "How Double Identity Profiles Empower Modern Creators",
        creatorName = "Elena Vance",
        creatorHandle = "elenavance.design",
        creatorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
        duration = "4:12",
        views = "118K",
        appreciatesCount = 7300,
        commentsCount = 410,
        tags = listOf("SocialTech", "Creators", "NEXIS"),
        isShort = false,
      ),
      VideoItem(
        id = "vid_4",
        title = "Micro-interactions & Haptics in Jetpack Compose",
        creatorName = "Marcus Thorne",
        creatorHandle = "mthorne_ai",
        creatorAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
        thumbnailUrl = "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
        duration = "0:45",
        views = "240K",
        appreciatesCount = 21400,
        commentsCount = 890,
        tags = listOf("Shorts", "Android", "Kotlin"),
        isShort = true,
      ),
    ),
  )
  val videos: StateFlow<List<VideoItem>> = _videos.asStateFlow()

  // Creator Spaces directory
  private val _creatorSpaces = MutableStateFlow(
    listOf(
      CreatorSpace(
        id = "space_1",
        creatorId = "creator_nexis",
        name = "Nexis Studio Hub",
        handle = "nexis_studio",
        tagLine = "Official spatial UI lab & generative technology research.",
        category = "Technology & Design",
        bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
        avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
        subscriberCount = 28400,
        isSubscribed = true,
      ),
      CreatorSpace(
        id = "space_2",
        creatorId = "creator_synth",
        name = "Neon Synthetics",
        handle = "neonsynths",
        tagLine = "Cybernetic audio production, modular patching, and chillwave.",
        category = "Music & Sound",
        bannerUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&q=80",
        avatarUrl = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
        subscriberCount = 15800,
        isSubscribed = false,
      ),
      CreatorSpace(
        id = "space_3",
        creatorId = "creator_arch",
        name = "Minimalist Architecture",
        handle = "minimal_arch",
        tagLine = "Brutalist structures, Japanese zen gardens, and organic spaces.",
        category = "Architecture",
        bannerUrl = "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=800&q=80",
        avatarUrl = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
        subscriberCount = 41200,
        isSubscribed = true,
      ),
    ),
  )
  val creatorSpaces: StateFlow<List<CreatorSpace>> = _creatorSpaces.asStateFlow()

  // Navigation handlers
  fun setBottomTab(tab: BottomTab) {
    _currentTab.value = tab
    if (tab == BottomTab.HOME) {
      _activeScreen.value = ActiveScreen.FEED
    }
  }

  fun navigateTo(screen: ActiveScreen) {
    _activeScreen.value = screen
    _currentTab.value = BottomTab.HOME
  }

  fun setProfileIdentity(identity: ProfileIdentity) {
    _profileIdentity.value = identity
  }

  // Universal Create
  fun openUniversalCreate() {
    _isUniversalCreateOpen.value = true
  }

  fun closeUniversalCreate() {
    _isUniversalCreateOpen.value = false
  }

  fun openCreateDialog(dialogType: CreateDialogType) {
    _isUniversalCreateOpen.value = false
    _activeCreateDialog.value = dialogType
  }

  fun closeCreateDialog() {
    _activeCreateDialog.value = CreateDialogType.None
  }

  fun triggerDisabledVideoUploadNotice() {
    _isUniversalCreateOpen.value = false
    _showVideoUploadNotice.value = true
  }

  fun dismissVideoUploadNotice() {
    _showVideoUploadNotice.value = false
  }

  // Post Interactions
  fun toggleAppreciate(post: Post) {
    viewModelScope.launch {
      postRepository.toggleAppreciate(post.id)
    }
  }

  fun toggleSave(post: Post) {
    viewModelScope.launch {
      postRepository.toggleSave(post.id)
      val msg = if (!post.isSaved) "Post saved to your bookmarks" else "Post removed from bookmarks"
      _snackbarMessages.emit(msg)
    }
  }

  fun openComments(post: Post) {
    _activeCommentPost.value = post
  }

  fun closeComments() {
    _activeCommentPost.value = null
  }

  fun submitComment(postId: String, text: String) {
    if (text.isBlank()) return
    val user = currentUser.value
    val comment = Comment(
      id = "comment_${UUID.randomUUID().toString().take(8)}",
      postId = postId,
      authorId = user?.uid ?: "user_local",
      authorName = user?.displayName ?: "Nexis Member",
      authorHandle = user?.handle ?: "nexis_user",
      authorAvatar = user?.avatarUrl ?: "",
      content = text.trim(),
      timestamp = System.currentTimeMillis(),
    )
    viewModelScope.launch {
      postRepository.addComment(comment)
      _snackbarMessages.emit("Comment posted")
    }
  }

  fun openReport(post: Post) {
    _activeReportPost.value = post
  }

  fun closeReport() {
    _activeReportPost.value = null
  }

  fun submitReport(postId: String, reason: ReportReason, details: String) {
    viewModelScope.launch {
      postRepository.reportPost(postId, reason, details)
      _activeReportPost.value = null
      _snackbarMessages.emit("Report submitted. Thank you for keeping NEXIS safe.")
    }
  }

  fun sharePost(post: Post) {
    viewModelScope.launch {
      _snackbarMessages.emit("Link copied to clipboard for @${post.authorHandle}'s post")
    }
  }

  // Content Creation
  fun createTextPost(content: String, isCreatorSpace: Boolean, communityId: String?, communityName: String?) {
    if (content.isBlank()) return
    val user = currentUser.value
    val authorName = if (isCreatorSpace && user?.creatorName?.isNotBlank() == true) user.creatorName else (user?.displayName ?: "Nexis Explorer")
    val authorHandle = if (isCreatorSpace) "${user?.handle}_space" else (user?.handle ?: "nexis_user")

    val newPost = Post(
      id = "post_${UUID.randomUUID().toString().take(8)}",
      authorId = user?.uid ?: "user_local",
      authorName = authorName,
      authorHandle = authorHandle,
      authorAvatar = user?.avatarUrl ?: "",
      content = content.trim(),
      imageUrls = emptyList(),
      timestamp = System.currentTimeMillis(),
      isCreatorPost = isCreatorSpace,
      communityId = communityId,
      communityName = communityName,
    )
    viewModelScope.launch {
      postRepository.createPost(newPost)
      _activeCreateDialog.value = CreateDialogType.None
      _snackbarMessages.emit("Post published to NEXIS feed")
    }
  }

  fun createImagePost(content: String, imageUrls: List<String>, isCreatorSpace: Boolean, communityId: String?, communityName: String?) {
    if (imageUrls.isEmpty() && content.isBlank()) return
    val user = currentUser.value
    val authorName = if (isCreatorSpace && user?.creatorName?.isNotBlank() == true) user.creatorName else (user?.displayName ?: "Nexis Explorer")
    val authorHandle = if (isCreatorSpace) "${user?.handle}_space" else (user?.handle ?: "nexis_user")

    val newPost = Post(
      id = "post_${UUID.randomUUID().toString().take(8)}",
      authorId = user?.uid ?: "user_local",
      authorName = authorName,
      authorHandle = authorHandle,
      authorAvatar = user?.avatarUrl ?: "",
      content = content.trim(),
      imageUrls = imageUrls,
      timestamp = System.currentTimeMillis(),
      isCreatorPost = isCreatorSpace,
      communityId = communityId,
      communityName = communityName,
    )
    viewModelScope.launch {
      postRepository.createPost(newPost)
      _activeCreateDialog.value = CreateDialogType.None
      _snackbarMessages.emit("Visual post published successfully")
    }
  }

  fun createCommunity(name: String, description: String, category: String, isPrivate: Boolean) {
    if (name.isBlank()) return
    val community = Community(
      id = "comm_${UUID.randomUUID().toString().take(8)}",
      name = name.trim(),
      description = description.trim(),
      category = category.ifBlank { "General" },
      membersCount = 1,
      iconUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&q=80",
      bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
      isJoined = true,
      isPrivate = isPrivate,
    )
    viewModelScope.launch {
      communityRepository.createCommunity(community)
      _activeCreateDialog.value = CreateDialogType.None
      _snackbarMessages.emit("Community '${community.name}' created!")
    }
  }

  fun createCreatorSpace(name: String, tagLine: String, category: String) {
    if (name.isBlank()) return
    val user = currentUser.value
    val newSpace = CreatorSpace(
      id = "space_${UUID.randomUUID().toString().take(8)}",
      creatorId = user?.uid ?: "user_local",
      name = name.trim(),
      handle = name.trim().lowercase().replace("\\s+".toRegex(), "_"),
      tagLine = tagLine.trim(),
      category = category.ifBlank { "Creator Space" },
      bannerUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
      avatarUrl = user?.avatarUrl ?: "",
      subscriberCount = 1,
      isSubscribed = true,
      verifiedBadge = true,
    )
    _creatorSpaces.value = listOf(newSpace) + _creatorSpaces.value

    // Also update user creator status
    if (user != null) {
      val updatedProfile = user.copy(
        isCreator = true,
        creatorName = name.trim(),
        creatorBio = tagLine.trim(),
        creatorCategory = category,
      )
      viewModelScope.launch {
        authRepository.updateCurrentUser(updatedProfile)
      }
    }
    _activeCreateDialog.value = CreateDialogType.None
    viewModelScope.launch {
      _snackbarMessages.emit("Creator Space '${newSpace.name}' activated!")
    }
  }

  fun toggleJoinCommunity(communityId: String) {
    viewModelScope.launch {
      communityRepository.toggleJoin(communityId)
    }
  }

  fun toggleSubscribeSpace(spaceId: String) {
    val list = _creatorSpaces.value.map { space ->
      if (space.id == spaceId) {
        val newSub = !space.isSubscribed
        space.copy(
          isSubscribed = newSub,
          subscriberCount = if (newSub) space.subscriberCount + 1 else (space.subscriberCount - 1).coerceAtLeast(0),
        )
      } else space
    }
    _creatorSpaces.value = list
  }
}
