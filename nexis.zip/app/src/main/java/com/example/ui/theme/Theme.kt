package com.example.ui.theme

import android.os.Build
import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.dynamicDarkColorScheme
import androidx.compose.material3.dynamicLightColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext

private val NexisDarkColorScheme = darkColorScheme(
  primary = NexisVioletLight,
  onPrimary = Color.Black,
  primaryContainer = NexisVioletDark,
  onPrimaryContainer = Color(0xFFEDE9FE),
  secondary = NexisCyanLight,
  onSecondary = Color.Black,
  secondaryContainer = NexisCyanDark,
  onSecondaryContainer = Color(0xFFCFFAFE),
  tertiary = NexisRoseLight,
  onTertiary = Color.Black,
  background = NexisDarkBg,
  onBackground = Color(0xFFF1F5F9),
  surface = NexisDarkSurface,
  onSurface = Color(0xFFF8FAFC),
  surfaceVariant = NexisDarkSurfaceVariant,
  onSurfaceVariant = Color(0xFFCBD5E1),
  outline = NexisDarkBorder,
)

private val NexisLightColorScheme = lightColorScheme(
  primary = NexisViolet,
  onPrimary = Color.White,
  primaryContainer = Color(0xFFEDE9FE),
  onPrimaryContainer = NexisVioletDark,
  secondary = NexisCyanDark,
  onSecondary = Color.White,
  secondaryContainer = Color(0xFFCFFAFE),
  onSecondaryContainer = Color(0xFF164E63),
  tertiary = NexisRose,
  onTertiary = Color.White,
  background = NexisLightBg,
  onBackground = Color(0xFF0F172A),
  surface = NexisLightSurface,
  onSurface = Color(0xFF0F172A),
  surfaceVariant = NexisLightSurfaceVariant,
  onSurfaceVariant = Color(0xFF475569),
  outline = NexisLightBorder,
)

@Composable
fun NexisTheme(
  darkTheme: Boolean = true, // Default to sleek futuristic dark identity
  dynamicColor: Boolean = false,
  content: @Composable () -> Unit,
) {
  val colorScheme = when {
    dynamicColor && Build.VERSION.SDK_INT >= Build.VERSION_CODES.S -> {
      val context = LocalContext.current
      if (darkTheme) dynamicDarkColorScheme(context) else dynamicLightColorScheme(context)
    }
    darkTheme -> NexisDarkColorScheme
    else -> NexisLightColorScheme
  }

  MaterialTheme(
    colorScheme = colorScheme,
    typography = Typography,
    content = content,
  )
}

@Composable
fun MyApplicationTheme(
  darkTheme: Boolean = isSystemInDarkTheme(),
  dynamicColor: Boolean = true,
  content: @Composable () -> Unit,
) {
  NexisTheme(darkTheme = darkTheme, dynamicColor = dynamicColor, content = content)
}
