package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.SlowMotionVideo
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.FloatingActionButtonDefaults
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet
import com.example.ui.viewmodel.BottomTab

@Composable
fun NexisBottomNavigation(
  currentTab: BottomTab,
  onTabSelected: (BottomTab) -> Unit,
  onUniversalCreateClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .testTag("nexis_bottom_navigation"),
    color = MaterialTheme.colorScheme.surface,
    tonalElevation = 8.dp,
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding(),
    ) {
      HorizontalDivider(
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
        thickness = 1.dp,
      )

      Box(
        modifier = Modifier
          .fillMaxWidth()
          .height(64.dp)
          .padding(horizontal = 24.dp),
        contentAlignment = Alignment.Center,
      ) {
        // Left & Right Tabs (Only HOME and VIDEO)
        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.SpaceBetween,
          verticalAlignment = Alignment.CenterVertically,
        ) {
          // Tab 1: HOME
          BottomNavTabItem(
            label = "HOME",
            iconFilled = Icons.Filled.Home,
            iconOutlined = Icons.Outlined.Home,
            isSelected = currentTab == BottomTab.HOME,
            testTag = "bottom_tab_home",
            onClick = { onTabSelected(BottomTab.HOME) },
            modifier = Modifier.weight(1f),
          )

          // Spacer in middle for Central Floating Action Button
          Spacer(modifier = Modifier.size(72.dp))

          // Tab 2: VIDEO
          BottomNavTabItem(
            label = "VIDEO",
            iconFilled = Icons.Filled.SlowMotionVideo,
            iconOutlined = Icons.Outlined.SlowMotionVideo,
            isSelected = currentTab == BottomTab.VIDEO,
            testTag = "bottom_tab_video",
            onClick = { onTabSelected(BottomTab.VIDEO) },
            modifier = Modifier.weight(1f),
          )
        }

        // Central Floating Action '+' Button for Universal Create
        Box(
          modifier = Modifier
            .offset(y = (-10).dp)
            .size(56.dp)
            .shadow(12.dp, CircleShape)
            .clip(CircleShape)
            .background(
              brush = Brush.linearGradient(
                colors = listOf(NexisViolet, NexisCyan),
              ),
            )
            .clickable(onClick = onUniversalCreateClick)
            .testTag("universal_create_fab"),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.Add,
            contentDescription = "Universal Create",
            tint = Color.White,
            modifier = Modifier.size(30.dp),
          )
        }
      }
    }
  }
}

@Composable
private fun BottomNavTabItem(
  label: String,
  iconFilled: androidx.compose.ui.graphics.vector.ImageVector,
  iconOutlined: androidx.compose.ui.graphics.vector.ImageVector,
  isSelected: Boolean,
  testTag: String,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val interactionSource = remember { MutableInteractionSource() }
  val activeColor = MaterialTheme.colorScheme.primary
  val inactiveColor = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)

  Column(
    modifier = modifier
      .clickable(
        interactionSource = interactionSource,
        indication = null,
        onClick = onClick,
      )
      .padding(vertical = 4.dp)
      .testTag(testTag),
    horizontalAlignment = Alignment.CenterHorizontally,
    verticalArrangement = Arrangement.Center,
  ) {
    Box(
      modifier = Modifier
        .clip(RoundedCornerShape(16.dp))
        .background(
          if (isSelected) activeColor.copy(alpha = 0.15f) else Color.Transparent,
        )
        .padding(horizontal = 16.dp, vertical = 4.dp),
      contentAlignment = Alignment.Center,
    ) {
      Icon(
        imageVector = if (isSelected) iconFilled else iconOutlined,
        contentDescription = label,
        tint = if (isSelected) activeColor else inactiveColor,
        modifier = Modifier.size(24.dp),
      )
    }

    Spacer(modifier = Modifier.height(2.dp))

    Text(
      text = label,
      style = MaterialTheme.typography.labelSmall.copy(
        fontSize = 11.sp,
        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
        letterSpacing = 0.8.sp,
      ),
      color = if (isSelected) activeColor else inactiveColor,
    )
  }
}
