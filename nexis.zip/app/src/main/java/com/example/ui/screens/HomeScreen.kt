package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ElectricBolt
import androidx.compose.material.icons.filled.Search
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.FeatureLauncherBar
import com.example.ui.components.PostCard
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet
import com.example.ui.viewmodel.ActiveScreen
import com.example.ui.viewmodel.BottomTab
import com.example.ui.viewmodel.NexisViewModel

@Composable
fun HomeScreen(
  viewModel: NexisViewModel,
  modifier: Modifier = Modifier,
) {
  val feedPosts by viewModel.feedPosts.collectAsStateWithLifecycle()
  val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding(),
  ) {
    // Top Bar Header
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 18.dp, vertical = 10.dp)
        .testTag("home_header"),
      horizontalArrangement = Arrangement.SpaceBetween,
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        Box(
          modifier = Modifier
            .size(34.dp)
            .clip(CircleShape)
            .background(Brush.linearGradient(listOf(NexisViolet, NexisCyan))),
          contentAlignment = Alignment.Center,
        ) {
          Icon(
            imageVector = Icons.Default.ElectricBolt,
            contentDescription = null,
            tint = Color.White,
            modifier = Modifier.size(20.dp),
          )
        }
        Spacer(modifier = Modifier.width(10.dp))
        Text(
          text = "NEXIS",
          style = MaterialTheme.typography.titleLarge.copy(
            fontWeight = FontWeight.Black,
            letterSpacing = 2.sp,
            fontSize = 22.sp,
          ),
          color = MaterialTheme.colorScheme.onBackground,
        )
      }

      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = { /* Search feed */ },
          modifier = Modifier.testTag("feed_search_button"),
        ) {
          Icon(
            imageVector = Icons.Default.Search,
            contentDescription = "Search NEXIS",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    }

    // MANDATORY REQUIREMENT 2:
    // Icon-Only Feature Launcher Bar: At the top of Home, add a horizontal icon bar
    // using ONLY modern Material 3 icons (NO text labels) for:
    // Profile, Communities (Groups substitute), Video Universe (Reels substitute), and Creator Spaces (Pages substitute).
    FeatureLauncherBar(
      activeScreen = activeScreen,
      onProfileClick = { viewModel.navigateTo(ActiveScreen.PROFILE) },
      onCommunitiesClick = { viewModel.navigateTo(ActiveScreen.COMMUNITIES) },
      onVideoUniverseClick = { viewModel.setBottomTab(BottomTab.VIDEO) },
      onCreatorSpacesClick = { viewModel.navigateTo(ActiveScreen.CREATOR_SPACES) },
    )

    HorizontalDivider(
      color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f),
      thickness = 0.8.dp,
    )

    // Personalized Feed
    if (feedPosts.isEmpty()) {
      Box(
        modifier = Modifier
          .fillMaxSize()
          .padding(32.dp),
        contentAlignment = Alignment.Center,
      ) {
        CircularProgressIndicator(color = NexisViolet)
      }
    } else {
      LazyColumn(
        modifier = Modifier
          .fillMaxSize()
          .testTag("personalized_feed_list"),
        contentPadding = PaddingValues(top = 8.dp, bottom = 80.dp),
      ) {
        items(feedPosts, key = { it.id }) { post ->
          PostCard(
            post = post,
            onAppreciateClick = { viewModel.toggleAppreciate(post) },
            onCommentClick = { viewModel.openComments(post) },
            onShareClick = { viewModel.sharePost(post) },
            onSaveClick = { viewModel.toggleSave(post) },
            onReportClick = { viewModel.openReport(post) },
          )
        }
      }
    }
  }
}
