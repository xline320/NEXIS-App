package com.example.ui.components

import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Flag
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.RadioButton
import androidx.compose.material3.RadioButtonDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.Post
import com.example.data.model.ReportReason
import com.example.ui.theme.NexisRose

@Composable
fun ReportDialog(
  post: Post,
  onDismiss: () -> Unit,
  onSubmitReport: (ReportReason, String) -> Unit,
  modifier: Modifier = Modifier,
) {
  var selectedReason by remember { mutableStateOf(ReportReason.SPAM) }
  var additionalNotes by remember { mutableStateOf("") }

  AlertDialog(
    onDismissRequest = onDismiss,
    icon = {
      Icon(
        imageVector = Icons.Default.Flag,
        contentDescription = null,
        tint = NexisRose,
        modifier = Modifier.size(28.dp),
      )
    },
    title = {
      Text(
        text = "Report Content",
        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
        color = MaterialTheme.colorScheme.onSurface,
      )
    },
    text = {
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .verticalScroll(rememberScrollState()),
      ) {
        Text(
          text = "Help maintain NEXIS community integrity. Why are you reporting this post by @${post.authorHandle}?",
          style = MaterialTheme.typography.bodySmall,
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(12.dp))

        ReportReason.entries.forEach { reason ->
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clickable { selectedReason = reason }
              .padding(vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically,
          ) {
            RadioButton(
              selected = selectedReason == reason,
              onClick = { selectedReason = reason },
              colors = RadioButtonDefaults.colors(
                selectedColor = NexisRose,
              ),
              modifier = Modifier.testTag("report_radio_${reason.name}"),
            )
            Spacer(modifier = Modifier.width(8.dp))
            Column {
              Text(
                text = reason.title,
                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold),
                color = MaterialTheme.colorScheme.onSurface,
              )
              Text(
                text = reason.description,
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                color = MaterialTheme.colorScheme.onSurfaceVariant,
              )
            }
          }
        }

        Spacer(modifier = Modifier.height(10.dp))

        OutlinedTextField(
          value = additionalNotes,
          onValueChange = { additionalNotes = it },
          label = { Text("Additional context (optional)") },
          placeholder = { Text("Provide any details that will help our safety moderators...") },
          modifier = Modifier
            .fillMaxWidth()
            .testTag("report_notes_input"),
          maxLines = 3,
        )
      }
    },
    confirmButton = {
      Button(
        onClick = { onSubmitReport(selectedReason, additionalNotes) },
        colors = ButtonDefaults.buttonColors(containerColor = NexisRose),
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("submit_report_button"),
      ) {
        Text("Submit Report", color = androidx.compose.ui.graphics.Color.White)
      }
    },
    dismissButton = {
      OutlinedButton(
        onClick = onDismiss,
        shape = RoundedCornerShape(12.dp),
        modifier = Modifier.testTag("cancel_report_button"),
      ) {
        Text("Cancel")
      }
    },
    modifier = modifier.testTag("report_modal_dialog"),
  )
}
