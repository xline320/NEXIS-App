package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.SlowMotionVideo
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.minimumInteractiveComponentSize
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.unit.dp
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet
import com.example.ui.viewmodel.ActiveScreen

@Composable
fun FeatureLauncherBar(
  activeScreen: ActiveScreen,
  onProfileClick: () -> Unit,
  onCommunitiesClick: () -> Unit,
  onVideoUniverseClick: () -> Unit,
  onCreatorSpacesClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Row(
    modifier = modifier
      .fillMaxWidth()
      .padding(horizontal = 16.dp, vertical = 8.dp)
      .testTag("feature_launcher_bar"),
    horizontalArrangement = Arrangement.SpaceBetween,
    verticalAlignment = Alignment.CenterVertically,
  ) {
    // 1. Profile (strictly icon-only)
    LauncherIconItem(
      icon = Icons.Filled.AccountCircle,
      contentDescription = "Profile",
      isSelected = activeScreen == ActiveScreen.PROFILE,
      testTag = "launcher_profile_icon",
      accentBrush = Brush.linearGradient(listOf(NexisViolet, NexisCyan)),
      onClick = onProfileClick,
    )

    // 2. Communities (Groups substitute, strictly icon-only)
    LauncherIconItem(
      icon = Icons.Filled.Groups,
      contentDescription = "Communities",
      isSelected = activeScreen == ActiveScreen.COMMUNITIES,
      testTag = "launcher_communities_icon",
      accentBrush = Brush.linearGradient(listOf(Color(0xFF3B82F6), Color(0xFF10B981))),
      onClick = onCommunitiesClick,
    )

    // 3. Video Universe (Reels substitute, strictly icon-only)
    LauncherIconItem(
      icon = Icons.Filled.SlowMotionVideo,
      contentDescription = "Video Universe",
      isSelected = false,
      testTag = "launcher_video_universe_icon",
      accentBrush = Brush.linearGradient(listOf(Color(0xFFEC4899), Color(0xFF8B5CF6))),
      onClick = onVideoUniverseClick,
    )

    // 4. Creator Spaces (Pages substitute, strictly icon-only)
    LauncherIconItem(
      icon = Icons.Filled.AutoAwesome,
      contentDescription = "Creator Spaces",
      isSelected = activeScreen == ActiveScreen.CREATOR_SPACES,
      testTag = "launcher_creator_spaces_icon",
      accentBrush = Brush.linearGradient(listOf(Color(0xFFF59E0B), Color(0xFFEC4899))),
      onClick = onCreatorSpacesClick,
    )
  }
}

@Composable
private fun LauncherIconItem(
  icon: ImageVector,
  contentDescription: String,
  isSelected: Boolean,
  testTag: String,
  accentBrush: Brush,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val surfaceColor = MaterialTheme.colorScheme.surfaceVariant
  val iconColor = if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant

  Box(
    modifier = modifier
      .size(54.dp)
      .clip(CircleShape)
      .background(if (isSelected) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f) else surfaceColor)
      .border(
        width = if (isSelected) 2.dp else 1.dp,
        brush = if (isSelected) accentBrush else Brush.linearGradient(listOf(MaterialTheme.colorScheme.outline.copy(alpha = 0.3f), MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))),
        shape = CircleShape,
      )
      .clickable(onClick = onClick)
      .minimumInteractiveComponentSize()
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Icon(
      imageVector = icon,
      contentDescription = contentDescription,
      tint = iconColor,
      modifier = Modifier.size(28.dp),
    )
  }
}
