package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddPhotoAlternate
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.EditNote
import androidx.compose.material.icons.filled.Groups
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun UniversalCreateSheet(
  onDismiss: () -> Unit,
  onSelectTextPost: () -> Unit,
  onSelectImagePost: () -> Unit,
  onSelectCreateCommunity: () -> Unit,
  onSelectCreateSpace: () -> Unit,
  onSelectDisabledVideoUpload: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)

  ModalBottomSheet(
    onDismissRequest = onDismiss,
    sheetState = sheetState,
    containerColor = MaterialTheme.colorScheme.surface,
    modifier = modifier.testTag("universal_create_sheet"),
  ) {
    Column(
      modifier = Modifier
        .fillMaxWidth()
        .navigationBarsPadding()
        .padding(bottom = 20.dp),
    ) {
      // Header
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 8.dp),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically,
      ) {
        Column {
          Text(
            text = "Universal Create",
            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
            color = MaterialTheme.colorScheme.onSurface,
          )
          Text(
            text = "What would you like to contribute to NEXIS?",
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }

        IconButton(
          onClick = onDismiss,
          modifier = Modifier.testTag("close_universal_create"),
        ) {
          Icon(
            imageVector = Icons.Default.Close,
            contentDescription = "Close",
            tint = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }

      HorizontalDivider(
        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f),
        modifier = Modifier.padding(vertical = 8.dp),
      )

      // Actions Column
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp),
      ) {
        // 1. Text Post
        CreateOptionRow(
          icon = Icons.Default.EditNote,
          title = "Text Post",
          subtitle = "Share insights, questions, or brief status updates",
          accentColor = NexisViolet,
          testTag = "create_option_text_post",
          onClick = onSelectTextPost,
        )

        // 2. Image Post
        CreateOptionRow(
          icon = Icons.Default.AddPhotoAlternate,
          title = "Image Post",
          subtitle = "Share photography, design renders, or visual galleries",
          accentColor = NexisCyan,
          testTag = "create_option_image_post",
          onClick = onSelectImagePost,
        )

        // 3. Create Community
        CreateOptionRow(
          icon = Icons.Default.Groups,
          title = "Create Community",
          subtitle = "Start a topic collective for discussions & collaboration",
          accentColor = Color(0xFF10B981),
          testTag = "create_option_community",
          onClick = onSelectCreateCommunity,
        )

        // 4. Create Space
        CreateOptionRow(
          icon = Icons.Default.AutoAwesome,
          title = "Create Space",
          subtitle = "Launch an official Creator Space with brand analytics",
          accentColor = Color(0xFFF59E0B),
          testTag = "create_option_space",
          onClick = onSelectCreateSpace,
        )

        // 5. Video Upload (Explicitly DISABLED)
        CreateOptionRow(
          icon = Icons.Default.VideocamOff,
          title = "Video Upload",
          subtitle = "Video uploading will be available in a future update.",
          accentColor = Color(0xFF64748B),
          isDisabled = true,
          badgeText = "COMING SOON",
          testTag = "create_option_video_upload_disabled",
          onClick = onSelectDisabledVideoUpload,
        )
      }
    }
  }
}

@Composable
private fun CreateOptionRow(
  icon: ImageVector,
  title: String,
  subtitle: String,
  accentColor: Color,
  testTag: String,
  onClick: () -> Unit,
  isDisabled: Boolean = false,
  badgeText: String? = null,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier
      .fillMaxWidth()
      .clip(RoundedCornerShape(16.dp))
      .clickable(onClick = onClick)
      .testTag(testTag),
    shape = RoundedCornerShape(16.dp),
    color = if (isDisabled) MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
    border = androidx.compose.foundation.BorderStroke(
      width = 1.dp,
      color = if (isDisabled) MaterialTheme.colorScheme.outline.copy(alpha = 0.2f) else accentColor.copy(alpha = 0.3f),
    ),
  ) {
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(14.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(46.dp)
          .clip(CircleShape)
          .background(accentColor.copy(alpha = 0.15f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(
          imageVector = icon,
          contentDescription = null,
          tint = if (isDisabled) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.6f) else accentColor,
          modifier = Modifier.size(24.dp),
        )
      }

      Spacer(modifier = Modifier.width(14.dp))

      Column(modifier = Modifier.weight(1f)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
          Text(
            text = title,
            style = MaterialTheme.typography.titleMedium.copy(
              fontWeight = FontWeight.SemiBold,
              fontSize = 15.sp,
            ),
            color = if (isDisabled) MaterialTheme.colorScheme.onSurfaceVariant else MaterialTheme.colorScheme.onSurface,
          )

          if (badgeText != null) {
            Spacer(modifier = Modifier.width(8.dp))
            Surface(
              shape = RoundedCornerShape(6.dp),
              color = MaterialTheme.colorScheme.surfaceVariant,
              border = androidx.compose.foundation.BorderStroke(0.8.dp, MaterialTheme.colorScheme.outline),
            ) {
              Row(
                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                verticalAlignment = Alignment.CenterVertically,
              ) {
                Icon(
                  imageVector = Icons.Default.Lock,
                  contentDescription = null,
                  modifier = Modifier.size(10.dp),
                  tint = MaterialTheme.colorScheme.onSurfaceVariant,
                )
                Spacer(modifier = Modifier.width(3.dp))
                Text(
                  text = badgeText,
                  style = MaterialTheme.typography.labelSmall.copy(
                    fontSize = 9.sp,
                    fontWeight = FontWeight.Bold,
                  ),
                  color = MaterialTheme.colorScheme.onSurfaceVariant,
                )
              }
            }
          }
        }

        Spacer(modifier = Modifier.height(2.dp))

        Text(
          text = subtitle,
          style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
          color = if (isDisabled) MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }
  }
}
