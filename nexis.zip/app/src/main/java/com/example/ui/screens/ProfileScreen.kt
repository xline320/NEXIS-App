package com.example.ui.screens

import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Bookmark
import androidx.compose.material.icons.filled.Campaign
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.Insights
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.PostAdd
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.WorkspacePremium
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Tab
import androidx.compose.material3.TabRow
import androidx.compose.material3.TabRowDefaults
import androidx.compose.material3.TabRowDefaults.tabIndicatorOffset
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.Post
import com.example.data.model.Profile
import com.example.ui.components.PostCard
import com.example.ui.theme.NexisCyan
import com.example.ui.theme.NexisViolet
import com.example.ui.viewmodel.ActiveScreen
import com.example.ui.viewmodel.NexisViewModel
import com.example.ui.viewmodel.ProfileIdentity

@Composable
fun ProfileScreen(
  viewModel: NexisViewModel,
  onBack: () -> Unit,
  modifier: Modifier = Modifier,
) {
  val profileIdentity by viewModel.profileIdentity.collectAsStateWithLifecycle()
  val currentUser by viewModel.currentUser.collectAsStateWithLifecycle()
  val feedPosts by viewModel.feedPosts.collectAsStateWithLifecycle()

  Column(
    modifier = modifier
      .fillMaxSize()
      .background(MaterialTheme.colorScheme.background)
      .statusBarsPadding(),
  ) {
    // Top Bar with Back Navigation
    Row(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 12.dp, vertical = 6.dp),
      verticalAlignment = Alignment.CenterVertically,
      horizontalArrangement = Arrangement.SpaceBetween,
    ) {
      Row(verticalAlignment = Alignment.CenterVertically) {
        IconButton(
          onClick = onBack,
          modifier = Modifier.testTag("profile_back_button"),
        ) {
          Icon(
            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
            contentDescription = "Back",
            tint = MaterialTheme.colorScheme.onSurface,
          )
        }
        Text(
          text = currentUser?.displayName ?: "Profile",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
      }

      IconButton(
        onClick = { /* Settings */ },
        modifier = Modifier.testTag("profile_settings_button"),
      ) {
        Icon(
          imageVector = Icons.Default.Settings,
          contentDescription = "Settings",
          tint = MaterialTheme.colorScheme.onSurfaceVariant,
        )
      }
    }

    // MANDATORY REQUIREMENT 5: DOUBLE IDENTITY SWITCHER
    // Interactive switcher between "Social Profile" and "Creator Space"
    Surface(
      modifier = Modifier
        .fillMaxWidth()
        .padding(horizontal = 16.dp, vertical = 6.dp)
        .testTag("double_identity_switcher"),
      shape = RoundedCornerShape(16.dp),
      color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
      border = CardDefaults.outlinedCardBorder().copy(
        brush = Brush.horizontalGradient(
          listOf(MaterialTheme.colorScheme.outline.copy(alpha = 0.4f), MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
        ),
      ),
    ) {
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(4.dp),
      ) {
        // Option 1: Social Profile
        IdentitySwitchTab(
          label = "Social Profile",
          icon = Icons.Default.Person,
          isSelected = profileIdentity == ProfileIdentity.SOCIAL,
          testTag = "identity_tab_social",
          activeColor = NexisCyan,
          onClick = { viewModel.setProfileIdentity(ProfileIdentity.SOCIAL) },
          modifier = Modifier.weight(1f),
        )

        // Option 2: Creator Space
        IdentitySwitchTab(
          label = "Creator Space",
          icon = Icons.Default.AutoAwesome,
          isSelected = profileIdentity == ProfileIdentity.CREATOR,
          testTag = "identity_tab_creator",
          activeColor = NexisViolet,
          onClick = { viewModel.setProfileIdentity(ProfileIdentity.CREATOR) },
          modifier = Modifier.weight(1f),
        )
      }
    }

    // Dynamic Body depending on Selected Identity
    AnimatedContent(
      targetState = profileIdentity,
      transitionSpec = { fadeIn() togetherWith fadeOut() },
      label = "identity_content",
      modifier = Modifier.fillMaxSize(),
    ) { identity ->
      when (identity) {
        ProfileIdentity.SOCIAL -> SocialProfileView(
          profile = currentUser,
          posts = feedPosts,
          viewModel = viewModel,
        )
        ProfileIdentity.CREATOR -> CreatorSpaceView(
          profile = currentUser,
          posts = feedPosts.filter { it.isCreatorPost },
          viewModel = viewModel,
        )
      }
    }
  }
}

@Composable
private fun IdentitySwitchTab(
  label: String,
  icon: ImageVector,
  isSelected: Boolean,
  testTag: String,
  activeColor: Color,
  onClick: () -> Unit,
  modifier: Modifier = Modifier,
) {
  Box(
    modifier = modifier
      .clip(RoundedCornerShape(12.dp))
      .background(
        if (isSelected) activeColor.copy(alpha = 0.2f) else Color.Transparent,
      )
      .clickable(onClick = onClick)
      .padding(vertical = 10.dp)
      .testTag(testTag),
    contentAlignment = Alignment.Center,
  ) {
    Row(verticalAlignment = Alignment.CenterVertically) {
      Icon(
        imageVector = icon,
        contentDescription = null,
        tint = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant,
        modifier = Modifier.size(18.dp),
      )
      Spacer(modifier = Modifier.width(8.dp))
      Text(
        text = label,
        style = MaterialTheme.typography.labelLarge.copy(
          fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
          fontSize = 13.sp,
        ),
        color = if (isSelected) activeColor else MaterialTheme.colorScheme.onSurfaceVariant,
      )
    }
  }
}

@Composable
private fun SocialProfileView(
  profile: Profile?,
  posts: List<Post>,
  viewModel: NexisViewModel,
) {
  var selectedTab by remember { mutableIntStateOf(0) }
  val tabTitles = listOf("Posts", "Saved", "Appreciated")

  val filteredPosts = when (selectedTab) {
    1 -> posts.filter { it.isSaved }
    2 -> posts.filter { it.isAppreciated }
    else -> posts
  }

  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("social_profile_view"),
    contentPadding = PaddingValues(bottom = 80.dp),
  ) {
    item {
      // Profile Info Header
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 20.dp, vertical = 12.dp),
      ) {
        Row(
          modifier = Modifier.fillMaxWidth(),
          verticalAlignment = Alignment.CenterVertically,
          horizontalArrangement = Arrangement.SpaceBetween,
        ) {
          // Avatar
          Box(
            modifier = Modifier
              .size(80.dp)
              .clip(CircleShape)
              .background(MaterialTheme.colorScheme.surfaceVariant)
              .border(2.dp, NexisCyan, CircleShape),
          ) {
            AsyncImage(
              model = profile?.avatarUrl,
              contentDescription = "User avatar",
              contentScale = ContentScale.Crop,
              modifier = Modifier.matchParentSize(),
            )
          }

          // Followers / Following Stats
          Row(horizontalArrangement = Arrangement.spacedBy(20.dp)) {
            StatItem(count = "${posts.size}", label = "Posts")
            StatItem(count = "${profile?.followersCount ?: 3840}", label = "Followers")
            StatItem(count = "${profile?.followingCount ?: 295}", label = "Following")
          }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Name and Handle
        Text(
          text = profile?.displayName ?: "Nasir Helalie",
          style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Text(
          text = "@${profile?.handle ?: "nasir_nexis"}",
          style = MaterialTheme.typography.bodyMedium,
          color = NexisCyan,
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
          text = profile?.bio ?: "Exploring the next frontier of social connection on NEXIS.",
          style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 20.sp),
          color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Spacer(modifier = Modifier.height(16.dp))

        // Actions
        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
          Button(
            onClick = { /* Edit Profile */ },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
          ) {
            Text("Edit Profile", color = MaterialTheme.colorScheme.onSurface)
          }
          OutlinedButton(
            onClick = { viewModel.openUniversalCreate() },
            modifier = Modifier.weight(1f),
            shape = RoundedCornerShape(12.dp),
          ) {
            Text("New Post")
          }
        }

        Spacer(modifier = Modifier.height(16.dp))

        // Tabs
        TabRow(
          selectedTabIndex = selectedTab,
          containerColor = Color.Transparent,
          contentColor = MaterialTheme.colorScheme.primary,
          indicator = { tabPositions ->
            TabRowDefaults.SecondaryIndicator(
              modifier = Modifier.tabIndicatorOffset(tabPositions[selectedTab]),
              color = NexisCyan,
            )
          },
        ) {
          tabTitles.forEachIndexed { index, title ->
            Tab(
              selected = selectedTab == index,
              onClick = { selectedTab = index },
              text = {
                Text(
                  text = title,
                  fontWeight = if (selectedTab == index) FontWeight.Bold else FontWeight.Normal,
                  fontSize = 13.sp,
                )
              },
            )
          }
        }
      }
    }

    if (filteredPosts.isEmpty()) {
      item {
        Box(
          modifier = Modifier
            .fillMaxWidth()
            .padding(40.dp),
          contentAlignment = Alignment.Center,
        ) {
          Text(
            text = "No ${tabTitles[selectedTab].lowercase()} posts yet",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )
        }
      }
    } else {
      items(filteredPosts, key = { it.id }) { post ->
        PostCard(
          post = post,
          onAppreciateClick = { viewModel.toggleAppreciate(post) },
          onCommentClick = { viewModel.openComments(post) },
          onShareClick = { viewModel.sharePost(post) },
          onSaveClick = { viewModel.toggleSave(post) },
          onReportClick = { viewModel.openReport(post) },
        )
      }
    }
  }
}

@Composable
private fun CreatorSpaceView(
  profile: Profile?,
  posts: List<Post>,
  viewModel: NexisViewModel,
) {
  LazyColumn(
    modifier = Modifier
      .fillMaxSize()
      .testTag("creator_space_view"),
    contentPadding = PaddingValues(bottom = 80.dp),
  ) {
    item {
      // Creator Space Banner Card
      Card(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = CardDefaults.outlinedCardBorder().copy(
          brush = Brush.linearGradient(listOf(NexisViolet, NexisCyan)),
        ),
      ) {
        Column(modifier = Modifier.padding(18.dp)) {
          Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween,
          ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
              Icon(
                imageVector = Icons.Default.WorkspacePremium,
                contentDescription = null,
                tint = Color(0xFFF59E0B),
                modifier = Modifier.size(24.dp),
              )
              Spacer(modifier = Modifier.width(8.dp))
              Text(
                text = "OFFICIAL CREATOR SPACE",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontWeight = FontWeight.Black,
                  letterSpacing = 1.sp,
                ),
                color = NexisViolet,
              )
            }

            Surface(
              shape = RoundedCornerShape(8.dp),
              color = NexisViolet.copy(alpha = 0.15f),
            ) {
              Text(
                text = profile?.creatorTier ?: "Level 4 Partner",
                style = MaterialTheme.typography.labelSmall.copy(
                  fontSize = 11.sp,
                  fontWeight = FontWeight.Bold,
                ),
                color = NexisViolet,
                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
              )
            }
          }

          Spacer(modifier = Modifier.height(14.dp))

          Row(verticalAlignment = Alignment.CenterVertically) {
            Text(
              text = profile?.creatorName ?: "Nexis Studio Hub",
              style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold),
              color = MaterialTheme.colorScheme.onSurface,
            )
            Spacer(modifier = Modifier.width(6.dp))
            Icon(
              imageVector = Icons.Default.CheckCircle,
              contentDescription = "Verified Creator",
              tint = NexisCyan,
              modifier = Modifier.size(20.dp),
            )
          }

          Text(
            text = profile?.creatorCategory ?: "AI & Interactive Media",
            style = MaterialTheme.typography.bodySmall,
            color = NexisCyan,
          )

          Spacer(modifier = Modifier.height(8.dp))

          Text(
            text = profile?.creatorBio ?: "Building immersive digital experiences and generative tech spaces.",
            style = MaterialTheme.typography.bodyMedium,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
          )

          Spacer(modifier = Modifier.height(16.dp))

          // Channel Analytics Highlights
          Row(
            modifier = Modifier
              .fillMaxWidth()
              .clip(RoundedCornerShape(14.dp))
              .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f))
              .padding(14.dp),
            horizontalArrangement = Arrangement.SpaceAround,
          ) {
            CreatorMetricItem(title = "Subscribers", value = "${profile?.subscribersCount ?: 28400}")
            CreatorMetricItem(title = "Total Reach", value = profile?.totalReach ?: "1.8M")
            CreatorMetricItem(title = "Monthly Views", value = profile?.monthlyViews ?: "4.2M")
          }
        }
      }
    }

    item {
      // Creator Studio Tools
      Column(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 16.dp, vertical = 8.dp),
      ) {
        Text(
          text = "Creator Tooling",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )
        Spacer(modifier = Modifier.height(10.dp))

        Row(
          modifier = Modifier.fillMaxWidth(),
          horizontalArrangement = Arrangement.spacedBy(10.dp),
        ) {
          ToolCard(
            icon = Icons.Default.Insights,
            title = "Analytics",
            subtitle = "+24% this week",
            modifier = Modifier.weight(1f),
          )
          ToolCard(
            icon = Icons.Default.Campaign,
            title = "Broadcast",
            subtitle = "Direct to subs",
            modifier = Modifier.weight(1f),
          )
        }
      }
    }

    item {
      // Creator Space Broadcast & Portfolio Posts
      Row(
        modifier = Modifier
          .fillMaxWidth()
          .padding(horizontal = 18.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.SpaceBetween,
      ) {
        Text(
          text = "Space Publications",
          style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
          color = MaterialTheme.colorScheme.onSurface,
        )

        Button(
          onClick = { viewModel.openUniversalCreate() },
          colors = ButtonDefaults.buttonColors(containerColor = NexisViolet),
          shape = RoundedCornerShape(10.dp),
          contentPadding = PaddingValues(horizontal = 12.dp, vertical = 4.dp),
        ) {
          Icon(Icons.Default.PostAdd, contentDescription = null, modifier = Modifier.size(16.dp))
          Spacer(modifier = Modifier.width(6.dp))
          Text("Publish", fontSize = 12.sp)
        }
      }
    }

    items(posts, key = { it.id }) { post ->
      PostCard(
        post = post,
        onAppreciateClick = { viewModel.toggleAppreciate(post) },
        onCommentClick = { viewModel.openComments(post) },
        onShareClick = { viewModel.sharePost(post) },
        onSaveClick = { viewModel.toggleSave(post) },
        onReportClick = { viewModel.openReport(post) },
      )
    }
  }
}

@Composable
private fun StatItem(count: String, label: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = count,
      style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold),
      color = MaterialTheme.colorScheme.onSurface,
    )
    Text(
      text = label,
      style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun CreatorMetricItem(title: String, value: String) {
  Column(horizontalAlignment = Alignment.CenterHorizontally) {
    Text(
      text = value,
      style = MaterialTheme.typography.titleMedium.copy(
        fontWeight = FontWeight.Black,
        color = NexisViolet,
      ),
    )
    Text(
      text = title,
      style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp),
      color = MaterialTheme.colorScheme.onSurfaceVariant,
    )
  }
}

@Composable
private fun ToolCard(
  icon: ImageVector,
  title: String,
  subtitle: String,
  modifier: Modifier = Modifier,
) {
  Surface(
    modifier = modifier,
    shape = RoundedCornerShape(14.dp),
    color = MaterialTheme.colorScheme.surface,
    border = CardDefaults.outlinedCardBorder(),
  ) {
    Row(
      modifier = Modifier.padding(12.dp),
      verticalAlignment = Alignment.CenterVertically,
    ) {
      Box(
        modifier = Modifier
          .size(36.dp)
          .clip(CircleShape)
          .background(MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
        contentAlignment = Alignment.Center,
      ) {
        Icon(imageVector = icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
      }
      Spacer(modifier = Modifier.width(10.dp))
      Column {
        Text(text = title, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.SemiBold))
        Text(text = subtitle, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp), color = NexisCyan)
      }
    }
  }
}
