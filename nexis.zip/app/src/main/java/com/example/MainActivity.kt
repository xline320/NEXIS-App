package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.Scaffold
import androidx.compose.material3.SnackbarHost
import androidx.compose.material3.SnackbarHostState
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.tooling.preview.Preview
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ReportReason
import com.example.ui.components.CommentBottomSheet
import com.example.ui.components.CreateCommunityDialog
import com.example.ui.components.CreateImagePostDialog
import com.example.ui.components.CreateSpaceDialog
import com.example.ui.components.CreateTextPostDialog
import com.example.ui.components.DisabledVideoUploadNoticeDialog
import com.example.ui.components.NexisBottomNavigation
import com.example.ui.components.ReportDialog
import com.example.ui.components.UniversalCreateSheet
import com.example.ui.screens.CommunitiesScreen
import com.example.ui.screens.CreatorSpacesScreen
import com.example.ui.screens.HomeScreen
import com.example.ui.screens.ProfileScreen
import com.example.ui.screens.VideoUniverseScreen
import com.example.ui.theme.NexisTheme
import com.example.ui.viewmodel.ActiveScreen
import com.example.ui.viewmodel.BottomTab
import com.example.ui.viewmodel.CreateDialogType
import com.example.ui.viewmodel.NexisViewModel
import kotlinx.coroutines.flow.collectLatest

class MainActivity : ComponentActivity() {
  private val viewModel: NexisViewModel by viewModels()

  override fun onCreate(savedInstanceState: Bundle?) {
    super.onCreate(savedInstanceState)
    enableEdgeToEdge()
    setContent {
      NexisTheme {
        NexisApp(viewModel = viewModel)
      }
    }
  }
}

@Composable
fun NexisApp(
  viewModel: NexisViewModel,
  modifier: Modifier = Modifier,
) {
  val currentTab by viewModel.currentTab.collectAsStateWithLifecycle()
  val activeScreen by viewModel.activeScreen.collectAsStateWithLifecycle()
  val isUniversalCreateOpen by viewModel.isUniversalCreateOpen.collectAsStateWithLifecycle()
  val activeCreateDialog by viewModel.activeCreateDialog.collectAsStateWithLifecycle()
  val activeCommentPost by viewModel.activeCommentPost.collectAsStateWithLifecycle()
  val activeReportPost by viewModel.activeReportPost.collectAsStateWithLifecycle()
  val showVideoUploadNotice by viewModel.showVideoUploadNotice.collectAsStateWithLifecycle()
  val communities by viewModel.communities.collectAsStateWithLifecycle()

  val snackbarHostState = remember { SnackbarHostState() }

  // Listen to snackbar feedback
  LaunchedEffect(Unit) {
    viewModel.snackbarMessages.collectLatest { message ->
      snackbarHostState.showSnackbar(message)
    }
  }

  // Back handler for sub-screens
  BackHandler(enabled = currentTab == BottomTab.VIDEO || activeScreen != ActiveScreen.FEED) {
    if (activeScreen != ActiveScreen.FEED) {
      viewModel.navigateTo(ActiveScreen.FEED)
    } else if (currentTab == BottomTab.VIDEO) {
      viewModel.setBottomTab(BottomTab.HOME)
    }
  }

  Scaffold(
    modifier = modifier
      .fillMaxSize()
      .testTag("nexis_root_scaffold"),
    bottomBar = {
      // ONLY TWO tabs: HOME and VIDEO, plus central '+' Universal Create button
      NexisBottomNavigation(
        currentTab = currentTab,
        onTabSelected = { viewModel.setBottomTab(it) },
        onUniversalCreateClick = { viewModel.openUniversalCreate() },
      )
    },
    snackbarHost = {
      SnackbarHost(
        hostState = snackbarHostState,
        modifier = Modifier.testTag("nexis_snackbar_host"),
      )
    },
  ) { innerPadding ->
    Box(
      modifier = Modifier
        .fillMaxSize()
        .padding(innerPadding),
    ) {
      AnimatedContent(
        targetState = Pair(currentTab, activeScreen),
        transitionSpec = { fadeIn() togetherWith fadeOut() },
        label = "main_screen_transition",
      ) { (tab, screen) ->
        when {
          tab == BottomTab.VIDEO -> {
            VideoUniverseScreen(viewModel = viewModel)
          }
          screen == ActiveScreen.PROFILE -> {
            ProfileScreen(
              viewModel = viewModel,
              onBack = { viewModel.navigateTo(ActiveScreen.FEED) },
            )
          }
          screen == ActiveScreen.COMMUNITIES -> {
            CommunitiesScreen(
              viewModel = viewModel,
              onBack = { viewModel.navigateTo(ActiveScreen.FEED) },
            )
          }
          screen == ActiveScreen.CREATOR_SPACES -> {
            CreatorSpacesScreen(
              viewModel = viewModel,
              onBack = { viewModel.navigateTo(ActiveScreen.FEED) },
            )
          }
          else -> {
            HomeScreen(viewModel = viewModel)
          }
        }
      }
    }

    // OVERLAYS & MODALS

    // 1. Universal Create Sheet
    if (isUniversalCreateOpen) {
      UniversalCreateSheet(
        onDismiss = { viewModel.closeUniversalCreate() },
        onSelectTextPost = { viewModel.openCreateDialog(CreateDialogType.TextPost) },
        onSelectImagePost = { viewModel.openCreateDialog(CreateDialogType.ImagePost) },
        onSelectCreateCommunity = { viewModel.openCreateDialog(CreateDialogType.CreateCommunity) },
        onSelectCreateSpace = { viewModel.openCreateDialog(CreateDialogType.CreateSpace) },
        onSelectDisabledVideoUpload = { viewModel.triggerDisabledVideoUploadNotice() },
      )
    }

    // 2. Create Dialogs
    when (activeCreateDialog) {
      is CreateDialogType.TextPost -> {
        CreateTextPostDialog(
          communities = communities,
          onDismiss = { viewModel.closeCreateDialog() },
          onPublish = { content, isCreatorSpace, communityId, communityName ->
            viewModel.createTextPost(content, isCreatorSpace, communityId, communityName)
          },
        )
      }
      is CreateDialogType.ImagePost -> {
        CreateImagePostDialog(
          communities = communities,
          onDismiss = { viewModel.closeCreateDialog() },
          onPublish = { content, images, isCreatorSpace, communityId, communityName ->
            viewModel.createImagePost(content, images, isCreatorSpace, communityId, communityName)
          },
        )
      }
      is CreateDialogType.CreateCommunity -> {
        CreateCommunityDialog(
          onDismiss = { viewModel.closeCreateDialog() },
          onCreate = { name, desc, cat, isPriv ->
            viewModel.createCommunity(name, desc, cat, isPriv)
          },
        )
      }
      is CreateDialogType.CreateSpace -> {
        CreateSpaceDialog(
          onDismiss = { viewModel.closeCreateDialog() },
          onCreate = { name, tagLine, cat ->
            viewModel.createCreatorSpace(name, tagLine, cat)
          },
        )
      }
      CreateDialogType.None -> {}
    }

    // 3. Comment Bottom Sheet
    activeCommentPost?.let { post ->
      CommentBottomSheet(
        post = post,
        viewModel = viewModel,
        onDismiss = { viewModel.closeComments() },
      )
    }

    // 4. Report Modal with predefined reasons
    activeReportPost?.let { post ->
      ReportDialog(
        post = post,
        onDismiss = { viewModel.closeReport() },
        onSubmitReport = { reason, notes ->
          viewModel.submitReport(post.id, reason, notes)
        },
      )
    }

    // 5. Disabled Video Upload Notice Dialog
    if (showVideoUploadNotice) {
      DisabledVideoUploadNoticeDialog(
        onDismiss = { viewModel.dismissVideoUploadNotice() },
      )
    }
  }
}

// Retained for screenshot test compatibility
@Composable
fun Greeting(name: String, modifier: Modifier = Modifier) {
  Text(text = "Hello $name!", modifier = modifier)
}

@Preview(showBackground = true)
@Composable
fun GreetingPreview() {
  NexisTheme { Greeting("Android") }
}
