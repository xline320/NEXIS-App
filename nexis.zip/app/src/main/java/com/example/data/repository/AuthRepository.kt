package com.example.data.repository

import android.content.Context
import android.util.Log
import com.example.data.local.NexisDatabase
import com.example.data.local.entity.ProfileEntity
import com.example.data.model.Profile
import com.example.data.remote.FirebaseClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class AuthRepository(private val context: Context, private val database: NexisDatabase) {
  private val scope = CoroutineScope(Dispatchers.IO)
  private val _currentUser = MutableStateFlow<Profile?>(null)
  val currentUser: StateFlow<Profile?> = _currentUser.asStateFlow()

  init {
    scope.launch {
      loadInitialUser()
    }
  }

  private suspend fun loadInitialUser() {
    val auth = FirebaseClient.getAuth()
    val firebaseUser = auth?.currentUser
    val uid = firebaseUser?.uid ?: "user_nexis_alpha"

    database.profileDao().getProfile(uid).collect { cached ->
      if (cached != null) {
        _currentUser.value = cached.toModel()
      } else {
        // Seed default profile
        val defaultProfile = Profile(
          uid = uid,
          email = firebaseUser?.email ?: "nasiruddin.helalie@gmail.com",
          displayName = "Nasir Helalie",
          handle = "nasir_nexis",
          bio = "Futurist & Creative Technologist crafting next-gen social interfaces on NEXIS.",
          avatarUrl = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=400&q=80",
          bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1200&q=80",
          isCreator = true,
          creatorName = "Nexis Studio Hub",
          creatorBio = "Exploring generative aesthetics, dynamic systems, and spatial interfaces. Official Creator Space.",
          creatorCategory = "AI & Interactive Media",
          subscribersCount = 28400,
          followersCount = 8920,
          followingCount = 412,
          creatorTier = "Elite Creator Partner",
          totalReach = "1.8M",
          monthlyViews = "4.2M",
        )
        database.profileDao().insertProfile(defaultProfile.toEntity())
        _currentUser.value = defaultProfile
      }
    }
  }

  suspend fun signInWithEmail(email: String, password: String): Result<Profile> {
    val auth = FirebaseClient.getAuth()
    return try {
      val uid = if (auth != null) {
        val authResult = auth.signInWithEmailAndPassword(email, password).await()
        authResult.user?.uid ?: "user_local_${email.hashCode()}"
      } else {
        "user_local_${email.hashCode()}"
      }

      val profile = Profile(
        uid = uid,
        email = email,
        displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() },
        handle = email.substringBefore("@").lowercase(),
        bio = "Active NEXIS member sharing authentic moments.",
        avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
        isCreator = false,
      )
      database.profileDao().insertProfile(profile.toEntity())
      _currentUser.value = profile
      Result.success(profile)
    } catch (e: Exception) {
      Log.w("AuthRepository", "Firebase auth failed, fallback to local session: ${e.message}")
      val fallbackProfile = Profile(
        uid = "user_local_${email.hashCode()}",
        email = email,
        displayName = email.substringBefore("@").replaceFirstChar { it.uppercase() },
        handle = email.substringBefore("@").lowercase(),
        bio = "Signed in locally to NEXIS.",
        avatarUrl = "https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?w=400&q=80",
      )
      database.profileDao().insertProfile(fallbackProfile.toEntity())
      _currentUser.value = fallbackProfile
      Result.success(fallbackProfile)
    }
  }

  suspend fun signUpWithEmail(
    email: String,
    password: String,
    displayName: String,
    handle: String,
  ): Result<Profile> {
    val auth = FirebaseClient.getAuth()
    return try {
      val uid = if (auth != null) {
        val authResult = auth.createUserWithEmailAndPassword(email, password).await()
        authResult.user?.uid ?: "user_local_${email.hashCode()}"
      } else {
        "user_local_${email.hashCode()}"
      }

      val profile = Profile(
        uid = uid,
        email = email,
        displayName = displayName.ifBlank { email.substringBefore("@") },
        handle = handle.ifBlank { email.substringBefore("@").lowercase() },
        bio = "Welcome to my NEXIS space!",
        avatarUrl = "https://images.unsplash.com/photo-1570295999919-56ceb5ecca61?w=400&q=80",
        isCreator = false,
      )
      database.profileDao().insertProfile(profile.toEntity())
      _currentUser.value = profile
      Result.success(profile)
    } catch (e: Exception) {
      Log.w("AuthRepository", "Firebase signup failed, fallback to local creation: ${e.message}")
      val fallbackProfile = Profile(
        uid = "user_local_${email.hashCode()}",
        email = email,
        displayName = displayName.ifBlank { email.substringBefore("@") },
        handle = handle.ifBlank { email.substringBefore("@").lowercase() },
        bio = "Welcome to my NEXIS space!",
      )
      database.profileDao().insertProfile(fallbackProfile.toEntity())
      _currentUser.value = fallbackProfile
      Result.success(fallbackProfile)
    }
  }

  suspend fun updateCurrentUser(profile: Profile) {
    database.profileDao().insertProfile(profile.toEntity())
    _currentUser.value = profile
  }

  fun signOut() {
    try {
      FirebaseClient.getAuth()?.signOut()
    } catch (e: Exception) {
      Log.w("AuthRepository", "Sign out exception: ${e.message}")
    }
    _currentUser.value = null
  }
}

fun ProfileEntity.toModel(): Profile = Profile(
  uid = uid,
  email = email,
  displayName = displayName,
  handle = handle,
  bio = bio,
  avatarUrl = avatarUrl,
  bannerUrl = bannerUrl,
  isCreator = isCreator,
  creatorName = creatorName,
  creatorBio = creatorBio,
  creatorCategory = creatorCategory,
  subscribersCount = subscribersCount,
  followersCount = followersCount,
  followingCount = followingCount,
  creatorTier = creatorTier,
  totalReach = totalReach,
  monthlyViews = monthlyViews,
)

fun Profile.toEntity(): ProfileEntity = ProfileEntity(
  uid = uid,
  email = email,
  displayName = displayName,
  handle = handle,
  bio = bio,
  avatarUrl = avatarUrl,
  bannerUrl = bannerUrl,
  isCreator = isCreator,
  creatorName = creatorName,
  creatorBio = creatorBio,
  creatorCategory = creatorCategory,
  subscribersCount = subscribersCount,
  followersCount = followersCount,
  followingCount = followingCount,
  creatorTier = creatorTier,
  totalReach = totalReach,
  monthlyViews = monthlyViews,
)
