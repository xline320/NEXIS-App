package com.example.data.remote

import android.content.Context
import android.util.Log
import com.google.firebase.FirebaseApp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

object FirebaseClient {
  private const val TAG = "FirebaseClient"
  private var isInitialized = false

  fun init(context: Context) {
    try {
      if (FirebaseApp.getApps(context).isEmpty()) {
        FirebaseApp.initializeApp(context)
      }
      isInitialized = true
    } catch (e: Exception) {
      Log.w(TAG, "Firebase initialization skipped or running in offline mode: ${e.message}")
      isInitialized = false
    }
  }

  fun getAuth(): FirebaseAuth? {
    return try {
      FirebaseAuth.getInstance()
    } catch (e: Exception) {
      Log.w(TAG, "FirebaseAuth unavailable, using local mock auth: ${e.message}")
      null
    }
  }

  fun getFirestore(): FirebaseFirestore? {
    return try {
      FirebaseFirestore.getInstance()
    } catch (e: Exception) {
      Log.w(TAG, "Firestore unavailable, using Room local persistence: ${e.message}")
      null
    }
  }
}
