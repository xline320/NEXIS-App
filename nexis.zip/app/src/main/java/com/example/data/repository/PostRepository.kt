package com.example.data.repository

import android.util.Log
import com.example.data.local.NexisDatabase
import com.example.data.local.entity.CommentEntity
import com.example.data.local.entity.PostEntity
import com.example.data.model.Comment
import com.example.data.model.Post
import com.example.data.model.ReportReason
import com.example.data.remote.FirebaseClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class PostRepository(private val database: NexisDatabase) {
  private val scope = CoroutineScope(Dispatchers.IO)
  private val TAG = "PostRepository"

  init {
    scope.launch {
      seedInitialPostsIfEmpty()
    }
  }

  fun getFeedPosts(): Flow<List<Post>> {
    return database.postDao().getAllPosts().map { entities ->
      entities.map { it.toModel() }
    }
  }

  suspend fun createPost(post: Post) {
    // 1. Room local cache (Immediate responsiveness & offline first)
    database.postDao().insertPost(post.toEntity())

    // 2. Firestore cloud sync
    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val data = hashMapOf(
            "id" to post.id,
            "authorId" to post.authorId,
            "authorName" to post.authorName,
            "authorHandle" to post.authorHandle,
            "authorAvatar" to post.authorAvatar,
            "content" to post.content,
            "imageUrls" to post.imageUrls,
            "timestamp" to post.timestamp,
            "appreciatesCount" to post.appreciatesCount,
            "commentsCount" to post.commentsCount,
            "sharesCount" to post.sharesCount,
            "isCreatorPost" to post.isCreatorPost,
            "communityId" to (post.communityId ?: ""),
            "communityName" to (post.communityName ?: ""),
          )
          firestore.collection("posts").document(post.id).set(data).await()
          Log.d(TAG, "Post successfully pushed to Firestore: ${post.id}")
        } catch (e: Exception) {
          Log.w(TAG, "Firestore post sync pending (offline): ${e.message}")
        }
      }
    }
  }

  suspend fun toggleAppreciate(postId: String) {
    val posts = database.postDao().getAllPosts().first()
    val target = posts.find { it.id == postId } ?: return
    val newAppreciated = !target.isAppreciated
    val newCount = if (newAppreciated) target.appreciatesCount + 1 else (target.appreciatesCount - 1).coerceAtLeast(0)

    database.postDao().updateAppreciate(postId, newAppreciated, newCount)

    // Sync to Firestore
    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          firestore.collection("posts").document(postId).update(
            "appreciatesCount", newCount,
          ).await()
        } catch (e: Exception) {
          Log.w(TAG, "Appreciate firestore update failed: ${e.message}")
        }
      }
    }
  }

  suspend fun toggleSave(postId: String) {
    val posts = database.postDao().getAllPosts().first()
    val target = posts.find { it.id == postId } ?: return
    val newSaved = !target.isSaved
    database.postDao().updateSaved(postId, newSaved)
  }

  suspend fun reportPost(postId: String, reason: ReportReason, additionalDetails: String) {
    Log.i(TAG, "Post reported: $postId for $reason: $additionalDetails")
    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val reportData = hashMapOf(
            "postId" to postId,
            "reason" to reason.name,
            "reasonTitle" to reason.title,
            "details" to additionalDetails,
            "timestamp" to System.currentTimeMillis(),
          )
          firestore.collection("reports").add(reportData).await()
        } catch (e: Exception) {
          Log.w(TAG, "Report submission to Firestore failed: ${e.message}")
        }
      }
    }
  }

  fun getComments(postId: String): Flow<List<Comment>> {
    return database.commentDao().getCommentsForPost(postId).map { entities ->
      entities.map { it.toModel() }
    }
  }

  suspend fun addComment(comment: Comment) {
    database.commentDao().insertComment(comment.toEntity())

    // Update comments count on post
    val posts = database.postDao().getAllPosts().first()
    val target = posts.find { it.id == comment.postId }
    if (target != null) {
      val updatedPost = target.copy(commentsCount = target.commentsCount + 1)
      database.postDao().insertPost(updatedPost)
    }

    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val commentData = hashMapOf(
            "id" to comment.id,
            "postId" to comment.postId,
            "authorId" to comment.authorId,
            "authorName" to comment.authorName,
            "authorHandle" to comment.authorHandle,
            "authorAvatar" to comment.authorAvatar,
            "content" to comment.content,
            "timestamp" to comment.timestamp,
          )
          firestore.collection("posts").document(comment.postId)
            .collection("comments").document(comment.id).set(commentData).await()
        } catch (e: Exception) {
          Log.w(TAG, "Comment firestore upload failed: ${e.message}")
        }
      }
    }
  }

  private suspend fun seedInitialPostsIfEmpty() {
    val existing = database.postDao().getAllPosts().first()
    if (existing.isEmpty()) {
      val initialPosts = listOf(
        PostEntity(
          id = "post_1",
          authorId = "creator_elena",
          authorName = "Elena Vance",
          authorHandle = "elenavance.design",
          authorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
          content = "Unveiling the new architectural paradigm for spatial design. Notice how negative space shapes the emotional cadence of social feeds. What do you think about fluid UI transitions? ✨🚀",
          imageUrls = listOf(
            "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=1000&q=80",
            "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=1000&q=80",
          ),
          timestamp = System.currentTimeMillis() - 1000 * 60 * 35,
          appreciatesCount = 1420,
          commentsCount = 68,
          sharesCount = 194,
          isAppreciated = false,
          isSaved = false,
          isCreatorPost = true,
          communityId = "comm_design",
          communityName = "Future Interfaces",
        ),
        PostEntity(
          id = "post_2",
          authorId = "user_marcus",
          authorName = "Marcus Thorne",
          authorHandle = "mthorne_ai",
          authorAvatar = "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=200&q=80",
          content = "NEXIS double identity feature is game-changing. Seamlessly flipping between my casual community identity and our production Creator Space without managing two separate logins is the future of content creation.",
          imageUrls = emptyList(),
          timestamp = System.currentTimeMillis() - 1000 * 60 * 120,
          appreciatesCount = 845,
          commentsCount = 31,
          sharesCount = 59,
          isAppreciated = true,
          isSaved = true,
          isCreatorPost = false,
          communityId = "comm_tech",
          communityName = "AI Builders",
        ),
        PostEntity(
          id = "post_3",
          authorId = "creator_kai",
          authorName = "Kai Chen",
          authorHandle = "kaichen_lens",
          authorAvatar = "https://images.unsplash.com/photo-1500648767791-00dcc994a43e?w=200&q=80",
          content = "Captured this serene twilight reflection over Tokyo's Shibuya crossing during golden hour. The city breathes in pulses of neon light. 🌆📸",
          imageUrls = listOf(
            "https://images.unsplash.com/photo-1503899036084-c55cdd92da26?w=1000&q=80",
          ),
          timestamp = System.currentTimeMillis() - 1000 * 60 * 360,
          appreciatesCount = 2890,
          commentsCount = 142,
          sharesCount = 380,
          isAppreciated = false,
          isSaved = false,
          isCreatorPost = true,
          communityId = null,
          communityName = null,
        ),
        PostEntity(
          id = "post_4",
          authorId = "user_clara",
          authorName = "Clara Dupont",
          authorHandle = "claradupont",
          authorAvatar = "https://images.unsplash.com/photo-1494790108377-be9c29b29330?w=200&q=80",
          content = "Morning coffee brew ritual: light roast Ethiopian pour-over with notes of bergamot and jasmine. What's your daily focus beverage? ☕️☀️",
          imageUrls = listOf(
            "https://images.unsplash.com/photo-1514432324607-a09d9b4aefdd?w=1000&q=80",
          ),
          timestamp = System.currentTimeMillis() - 1000 * 60 * 720,
          appreciatesCount = 430,
          commentsCount = 19,
          sharesCount = 12,
          isAppreciated = false,
          isSaved = false,
          isCreatorPost = false,
          communityId = null,
          communityName = null,
        ),
      )
      database.postDao().insertPosts(initialPosts)

      // Seed initial comments
      val initialComments = listOf(
        CommentEntity(
          id = "comm_c1",
          postId = "post_1",
          authorId = "user_alex",
          authorName = "Alex Rivera",
          authorHandle = "arivera",
          authorAvatar = "https://images.unsplash.com/photo-1522075469751-3a6694fb2f61?w=200&q=80",
          content = "The lighting dynamics in that render are spectacular! Did you use volumetric raymarching?",
          timestamp = System.currentTimeMillis() - 1000 * 60 * 20,
        ),
        CommentEntity(
          id = "comm_c2",
          postId = "post_1",
          authorId = "creator_elena",
          authorName = "Elena Vance",
          authorHandle = "elenavance.design",
          authorAvatar = "https://images.unsplash.com/photo-1534528741775-53994a69daeb?w=200&q=80",
          content = "Yes! Combined with real-time gradient dispersion shaders in Compose.",
          timestamp = System.currentTimeMillis() - 1000 * 60 * 12,
        ),
        CommentEntity(
          id = "comm_c3",
          postId = "post_2",
          authorId = "user_sam",
          authorName = "Samantha Wu",
          authorHandle = "sam_wu",
          authorAvatar = "https://images.unsplash.com/photo-1544005313-94ddf0286df2?w=200&q=80",
          content = "Totally agree. Having the creator space analytics built right into the profile switcher is so intuitive.",
          timestamp = System.currentTimeMillis() - 1000 * 60 * 45,
        ),
      )
      database.commentDao().insertComments(initialComments)
    }
  }
}

fun PostEntity.toModel(): Post = Post(
  id = id,
  authorId = authorId,
  authorName = authorName,
  authorHandle = authorHandle,
  authorAvatar = authorAvatar,
  content = content,
  imageUrls = imageUrls,
  timestamp = timestamp,
  appreciatesCount = appreciatesCount,
  commentsCount = commentsCount,
  sharesCount = sharesCount,
  isAppreciated = isAppreciated,
  isSaved = isSaved,
  isCreatorPost = isCreatorPost,
  communityId = communityId,
  communityName = communityName,
)

fun Post.toEntity(): PostEntity = PostEntity(
  id = id,
  authorId = authorId,
  authorName = authorName,
  authorHandle = authorHandle,
  authorAvatar = authorAvatar,
  content = content,
  imageUrls = imageUrls,
  timestamp = timestamp,
  appreciatesCount = appreciatesCount,
  commentsCount = commentsCount,
  sharesCount = sharesCount,
  isAppreciated = isAppreciated,
  isSaved = isSaved,
  isCreatorPost = isCreatorPost,
  communityId = communityId,
  communityName = communityName,
)

fun CommentEntity.toModel(): Comment = Comment(
  id = id,
  postId = postId,
  authorId = authorId,
  authorName = authorName,
  authorHandle = authorHandle,
  authorAvatar = authorAvatar,
  content = content,
  timestamp = timestamp,
)

fun Comment.toEntity(): CommentEntity = CommentEntity(
  id = id,
  postId = postId,
  authorId = authorId,
  authorName = authorName,
  authorHandle = authorHandle,
  authorAvatar = authorAvatar,
  content = content,
  timestamp = timestamp,
)
