package com.example.data.model

data class Post(
  val id: String,
  val authorId: String,
  val authorName: String,
  val authorHandle: String,
  val authorAvatar: String = "",
  val content: String,
  val imageUrls: List<String> = emptyList(),
  val timestamp: Long = System.currentTimeMillis(),
  val appreciatesCount: Int = 0,
  val commentsCount: Int = 0,
  val sharesCount: Int = 0,
  val isAppreciated: Boolean = false,
  val isSaved: Boolean = false,
  val isCreatorPost: Boolean = false,
  val communityId: String? = null,
  val communityName: String? = null,
)

data class Comment(
  val id: String,
  val postId: String,
  val authorId: String,
  val authorName: String,
  val authorHandle: String,
  val authorAvatar: String = "",
  val content: String,
  val timestamp: Long = System.currentTimeMillis(),
)

data class Profile(
  val uid: String,
  val email: String = "",
  val displayName: String = "Nexis Explorer",
  val handle: String = "nexis_user",
  val bio: String = "Exploring the next frontier of social connection on NEXIS.",
  val avatarUrl: String = "",
  val bannerUrl: String = "",
  // Double Identity fields
  val isCreator: Boolean = true,
  val creatorName: String = "Nexis Studio",
  val creatorBio: String = "Building immersive digital experiences and generative tech spaces.",
  val creatorCategory: String = "Tech & Creative Tech",
  val subscribersCount: Int = 14200,
  val followersCount: Int = 3840,
  val followingCount: Int = 295,
  val creatorTier: String = "Level 4 Partner",
  val totalReach: String = "480K",
  val monthlyViews: String = "1.2M",
)

data class Community(
  val id: String,
  val name: String,
  val description: String,
  val category: String,
  val membersCount: Int,
  val iconUrl: String = "",
  val bannerUrl: String = "",
  val isJoined: Boolean = false,
  val isPrivate: Boolean = false,
)

data class CreatorSpace(
  val id: String,
  val creatorId: String,
  val name: String,
  val handle: String,
  val tagLine: String,
  val category: String,
  val bannerUrl: String = "",
  val avatarUrl: String = "",
  val subscriberCount: Int = 0,
  val isSubscribed: Boolean = false,
  val verifiedBadge: Boolean = true,
)

data class VideoItem(
  val id: String,
  val title: String,
  val creatorName: String,
  val creatorHandle: String,
  val creatorAvatar: String = "",
  val thumbnailUrl: String = "",
  val duration: String,
  val views: String,
  val appreciatesCount: Int,
  val commentsCount: Int,
  val tags: List<String> = emptyList(),
  val isShort: Boolean = false,
)

enum class ReportReason(val title: String, val description: String) {
  SPAM("Spam or misleading", "Repeated unsolicited links, clickbait, or automated bots"),
  HARASSMENT("Harassment or bullying", "Targeted attacks, hateful slurs, or intimidation"),
  INAPPROPRIATE("Inappropriate or sensitive content", "Depicts explicit, adult, or graphic material"),
  MISINFORMATION("Misinformation", "Fabricated medical, financial, or civic claims"),
  COPYRIGHT("Copyright violation", "Unauthorized use of copyrighted multimedia material"),
  OTHER("Other reason", "Any violation not covered by the predefined categories"),
}
