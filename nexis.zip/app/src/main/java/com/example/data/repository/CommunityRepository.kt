package com.example.data.repository

import android.util.Log
import com.example.data.local.NexisDatabase
import com.example.data.local.entity.CommunityEntity
import com.example.data.model.Community
import com.example.data.remote.FirebaseClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.first
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class CommunityRepository(private val database: NexisDatabase) {
  private val scope = CoroutineScope(Dispatchers.IO)
  private val TAG = "CommunityRepository"

  init {
    scope.launch {
      seedInitialCommunitiesIfEmpty()
    }
  }

  fun getCommunities(): Flow<List<Community>> {
    return database.communityDao().getAllCommunities().map { list ->
      list.map { it.toModel() }
    }
  }

  suspend fun createCommunity(community: Community) {
    database.communityDao().insertCommunity(community.toEntity())

    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val data = hashMapOf(
            "id" to community.id,
            "name" to community.name,
            "description" to community.description,
            "category" to community.category,
            "membersCount" to community.membersCount,
            "iconUrl" to community.iconUrl,
            "bannerUrl" to community.bannerUrl,
            "isPrivate" to community.isPrivate,
          )
          firestore.collection("communities").document(community.id).set(data).await()
        } catch (e: Exception) {
          Log.w(TAG, "Community creation sync failed: ${e.message}")
        }
      }
    }
  }

  suspend fun toggleJoin(communityId: String) {
    val current = database.communityDao().getAllCommunities().first()
    val target = current.find { it.id == communityId } ?: return
    val newJoined = !target.isJoined
    val newCount = if (newJoined) target.membersCount + 1 else (target.membersCount - 1).coerceAtLeast(0)

    database.communityDao().updateMembership(communityId, newJoined, newCount)

    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          firestore.collection("communities").document(communityId).update(
            "membersCount", newCount,
          ).await()
        } catch (e: Exception) {
          Log.w(TAG, "Firestore community update failed: ${e.message}")
        }
      }
    }
  }

  private suspend fun seedInitialCommunitiesIfEmpty() {
    val existing = database.communityDao().getAllCommunities().first()
    if (existing.isEmpty()) {
      val seeds = listOf(
        CommunityEntity(
          id = "comm_design",
          name = "Future Interfaces",
          description = "Pioneering spatial computing, tactile feedback, and next-generation UI aesthetics.",
          category = "Design & UI/UX",
          membersCount = 18450,
          iconUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=200&q=80",
          bannerUrl = "https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?w=800&q=80",
          isJoined = true,
          isPrivate = false,
        ),
        CommunityEntity(
          id = "comm_tech",
          name = "AI Builders & Visionaries",
          description = "Engineers and researchers deploying real-world generative models and neural networks.",
          category = "Artificial Intelligence",
          membersCount = 32800,
          iconUrl = "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=200&q=80",
          bannerUrl = "https://images.unsplash.com/photo-1620712943543-bcc4688e7485?w=800&q=80",
          isJoined = true,
          isPrivate = false,
        ),
        CommunityEntity(
          id = "comm_synth",
          name = "Synthesizer & Cyber Audio",
          description = "Modular synths, ambient soundscapes, generative music, and cybernetic acoustics.",
          category = "Audio & Music",
          membersCount = 12900,
          iconUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=200&q=80",
          bannerUrl = "https://images.unsplash.com/photo-1511379938547-c1f69419868d?w=800&q=80",
          isJoined = false,
          isPrivate = false,
        ),
        CommunityEntity(
          id = "comm_creators",
          name = "Creator Space Guild",
          description = "A community for verified NEXIS creators to collaborate, exchange monetization strategies, and share production workflows.",
          category = "Creator Economy",
          membersCount = 9420,
          iconUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=200&q=80",
          bannerUrl = "https://images.unsplash.com/photo-1550745165-9bc0b252726f?w=800&q=80",
          isJoined = false,
          isPrivate = true,
        ),
      )
      database.communityDao().insertCommunities(seeds)
    }
  }
}

fun CommunityEntity.toModel(): Community = Community(
  id = id,
  name = name,
  description = description,
  category = category,
  membersCount = membersCount,
  iconUrl = iconUrl,
  bannerUrl = bannerUrl,
  isJoined = isJoined,
  isPrivate = isPrivate,
)

fun Community.toEntity(): CommunityEntity = CommunityEntity(
  id = id,
  name = name,
  description = description,
  category = category,
  membersCount = membersCount,
  iconUrl = iconUrl,
  bannerUrl = bannerUrl,
  isJoined = isJoined,
  isPrivate = isPrivate,
)
