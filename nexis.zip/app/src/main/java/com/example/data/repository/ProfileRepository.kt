package com.example.data.repository

import android.util.Log
import com.example.data.local.NexisDatabase
import com.example.data.model.Profile
import com.example.data.remote.FirebaseClient
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class ProfileRepository(private val database: NexisDatabase) {
  private val scope = CoroutineScope(Dispatchers.IO)
  private val TAG = "ProfileRepository"

  fun getProfile(uid: String): Flow<Profile?> {
    return database.profileDao().getProfile(uid).map { it?.toModel() }
  }

  suspend fun updateProfile(profile: Profile) {
    database.profileDao().insertProfile(profile.toEntity())

    val firestore = FirebaseClient.getFirestore()
    if (firestore != null) {
      scope.launch(Dispatchers.IO) {
        try {
          val data = hashMapOf(
            "uid" to profile.uid,
            "displayName" to profile.displayName,
            "handle" to profile.handle,
            "bio" to profile.bio,
            "avatarUrl" to profile.avatarUrl,
            "bannerUrl" to profile.bannerUrl,
            "isCreator" to profile.isCreator,
            "creatorName" to profile.creatorName,
            "creatorBio" to profile.creatorBio,
            "creatorCategory" to profile.creatorCategory,
            "subscribersCount" to profile.subscribersCount,
            "followersCount" to profile.followersCount,
            "followingCount" to profile.followingCount,
          )
          firestore.collection("profiles").document(profile.uid).set(data).await()
          Log.d(TAG, "Profile updated in Firestore: ${profile.uid}")
        } catch (e: Exception) {
          Log.w(TAG, "Firestore profile update failed: ${e.message}")
        }
      }
    }
  }
}
