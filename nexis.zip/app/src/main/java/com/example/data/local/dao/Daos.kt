package com.example.data.local.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import com.example.data.local.entity.CommentEntity
import com.example.data.local.entity.CommunityEntity
import com.example.data.local.entity.PostEntity
import com.example.data.local.entity.ProfileEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface PostDao {
  @Query("SELECT * FROM posts ORDER BY timestamp DESC")
  fun getAllPosts(): Flow<List<PostEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPosts(posts: List<PostEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertPost(post: PostEntity)

  @Query("UPDATE posts SET isAppreciated = :appreciated, appreciatesCount = :count WHERE id = :id")
  suspend fun updateAppreciate(id: String, appreciated: Boolean, count: Int)

  @Query("UPDATE posts SET isSaved = :saved WHERE id = :id")
  suspend fun updateSaved(id: String, saved: Boolean)

  @Query("DELETE FROM posts WHERE id = :id")
  suspend fun deletePost(id: String)
}

@Dao
interface ProfileDao {
  @Query("SELECT * FROM profiles WHERE uid = :uid LIMIT 1")
  fun getProfile(uid: String): Flow<ProfileEntity?>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertProfile(profile: ProfileEntity)
}

@Dao
interface CommunityDao {
  @Query("SELECT * FROM communities ORDER BY membersCount DESC")
  fun getAllCommunities(): Flow<List<CommunityEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunities(communities: List<CommunityEntity>)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertCommunity(community: CommunityEntity)

  @Query("UPDATE communities SET isJoined = :isJoined, membersCount = :count WHERE id = :id")
  suspend fun updateMembership(id: String, isJoined: Boolean, count: Int)
}

@Dao
interface CommentDao {
  @Query("SELECT * FROM comments WHERE postId = :postId ORDER BY timestamp ASC")
  fun getCommentsForPost(postId: String): Flow<List<CommentEntity>>

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertComment(comment: CommentEntity)

  @Insert(onConflict = OnConflictStrategy.REPLACE)
  suspend fun insertComments(comments: List<CommentEntity>)
}
