package com.example.data.local.entity

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "posts")
data class PostEntity(
  @PrimaryKey val id: String,
  val authorId: String,
  val authorName: String,
  val authorHandle: String,
  val authorAvatar: String,
  val content: String,
  val imageUrls: List<String>,
  val timestamp: Long,
  val appreciatesCount: Int,
  val commentsCount: Int,
  val sharesCount: Int,
  val isAppreciated: Boolean,
  val isSaved: Boolean,
  val isCreatorPost: Boolean,
  val communityId: String?,
  val communityName: String?,
)

@Entity(tableName = "profiles")
data class ProfileEntity(
  @PrimaryKey val uid: String,
  val email: String,
  val displayName: String,
  val handle: String,
  val bio: String,
  val avatarUrl: String,
  val bannerUrl: String,
  val isCreator: Boolean,
  val creatorName: String,
  val creatorBio: String,
  val creatorCategory: String,
  val subscribersCount: Int,
  val followersCount: Int,
  val followingCount: Int,
  val creatorTier: String,
  val totalReach: String,
  val monthlyViews: String,
)

@Entity(tableName = "communities")
data class CommunityEntity(
  @PrimaryKey val id: String,
  val name: String,
  val description: String,
  val category: String,
  val membersCount: Int,
  val iconUrl: String,
  val bannerUrl: String,
  val isJoined: Boolean,
  val isPrivate: Boolean,
)

@Entity(tableName = "comments")
data class CommentEntity(
  @PrimaryKey val id: String,
  val postId: String,
  val authorId: String,
  val authorName: String,
  val authorHandle: String,
  val authorAvatar: String,
  val content: String,
  val timestamp: Long,
)
