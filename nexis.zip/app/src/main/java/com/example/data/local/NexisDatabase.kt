package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.room.TypeConverters
import com.example.data.local.dao.CommentDao
import com.example.data.local.dao.CommunityDao
import com.example.data.local.dao.PostDao
import com.example.data.local.dao.ProfileDao
import com.example.data.local.entity.CommentEntity
import com.example.data.local.entity.CommunityEntity
import com.example.data.local.entity.PostEntity
import com.example.data.local.entity.ProfileEntity

@Database(
  entities = [
    PostEntity::class,
    ProfileEntity::class,
    CommunityEntity::class,
    CommentEntity::class,
  ],
  version = 1,
  exportSchema = false,
)
@TypeConverters(Converters::class)
abstract class NexisDatabase : RoomDatabase() {
  abstract fun postDao(): PostDao
  abstract fun profileDao(): ProfileDao
  abstract fun communityDao(): CommunityDao
  abstract fun commentDao(): CommentDao

  companion object {
    @Volatile
    private var INSTANCE: NexisDatabase? = null

    fun getDatabase(context: Context): NexisDatabase {
      return INSTANCE ?: synchronized(this) {
        val instance = Room.databaseBuilder(
          context.applicationContext,
          NexisDatabase::class.java,
          "nexis_database",
        ).fallbackToDestructiveMigration().build()
        INSTANCE = instance
        instance
      }
    }
  }
}
